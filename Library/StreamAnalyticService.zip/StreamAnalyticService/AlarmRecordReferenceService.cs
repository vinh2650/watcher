﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common.Helper;
using Core.Domain.Business;
using Core.Domain.Business.StreamAnalyticEntity;

namespace StreamAnalyticService
{
    public class AlarmRecordReferenceService:IAlarmRecordReferenceService
    {
        public void ExportToCsvAndUploadToBlob(List<AlarmRecord> alarmRecords)
        {
            #region prepare header

            var str = new StringBuilder();
            str.Append("LocalCellId,");
            str.Append("CellName,");
            str.Append("CellType,");
            str.Append("Attribute,");
            str.Append("Slogan,");
            str.Append("Severity,");
            str.Append("MoClass,");
            str.Append("MoInstance,");
            str.Append("AdditionInfo,");
            str.Append("ENodeBId,");
            str.Append("CreatedDateUtc,");

            str.Append("\r\n");
            foreach (var item in alarmRecords)
            {
                //LocalCellId
                str.Append("\"" + item.LocalCellId + "\",");
                str.Append("\"" + item.CellName + "\",");
                str.Append("" + (int)item.CellType + ",");
                str.Append("\"" + item.Attribute + "\",");
                str.Append("\"" + item.Slogan + "\",");
                str.Append("\"" + item.Severity + "\",");
                str.Append("\"" + item.MoClass + "\",");
                str.Append("\"" + item.MoInstance + "\",");
                str.Append("\"" + item.AdditionInfo + "\",");
                str.Append("\"" + item.ENodeBId + "\",");
                str.Append("\"" + item.CreatedDateUtc.ToString("yyyy-MM-dd'T'HH:mm:ss.000'Z'") + "\",");
                str.Append("\r\n");
            }
            var guid = Guid.NewGuid().ToString();
            var fileNamePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, guid + "-output-alarms.csv");

            FileStream fs = new FileStream(fileNamePath, FileMode.Create, FileAccess.ReadWrite);
            BinaryWriter bw = new BinaryWriter(fs);
            bw.Write(Encoding.UTF8.GetBytes(str.ToString()));
            bw.Close();
           
            // Retrieve reference to a blob
            var blobContainer = AzureHelper.AlarmCloudBlobContainer;
            for (var i = 1; i < 3; i++)
            {
                var datetime = DateTime.UtcNow.AddMinutes(i);


                var blobName = string.Format("{0}/{1}/output-alarms.csv", datetime.ToString("dd-MM-yyyy"), datetime.ToString("HH-mm"));
                var blob = blobContainer.GetBlockBlobReference(blobName);

                // Set the blob content type
                blob.Properties.ContentType = "text/csv";

                // Upload file into blob storage, basically copying it from local disk into Azure
                using (var fs2 = File.OpenRead(fileNamePath))
                {
                    blob.UploadFromStream(fs2);
                }
            }
          

            #endregion

        }
    }
}

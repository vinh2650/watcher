﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.ServiceBus.Messaging;
using Newtonsoft.Json;

namespace StreamAnalyticService.OndemandTesting
{
    public class SendingEventService:ISendingEventService
    {
        public SendingEventService()
        {
            
        }
        static string eventHubName = "testingamsnetworkalarm";
        static string connectionString =
            "Endpoint=sb://amsiotsystem.servicebus.windows.net/;SharedAccessKeyName=amstesting;SharedAccessKey=FTM1gesuHRype5fYi3eEM0OMSVo42di2m+MveUE+e2g=";

        public void SendListEvent(int second, List<EventRecord> eventRecords)
        {
            var eventHubClient = EventHubClient.CreateFromConnectionString(connectionString, eventHubName);

            foreach (var eventRecord in eventRecords)
            {
                try
                {
                    var jOb = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(eventRecord));
                    var evd = new EventData(jOb);
                    eventHubClient.Send(evd);
                }
                catch (Exception ex)
                {
                    
                    throw;
                }
               
            }
           
        }
    }
}

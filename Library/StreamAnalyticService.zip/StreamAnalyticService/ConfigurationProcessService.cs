﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Hosting;
using System.Xml;
using Common.Helper;
using Core.Domain.Business.StreamAnalyticEntity;
using Microsoft.ServiceBus.Messaging;
using Newtonsoft.Json;

namespace StreamAnalyticService
{
    public class ConfigurationProcessService:IConfigurationProcessService
    {
        private static readonly string senderConfigurationEventHub = ConfigurationManager.AppSettings["senderConfiguration.Path"];
        private static readonly string senderConfigurationConnectionString = ConfigurationManager.AppSettings["senderConfiguration.ConnectionString"];
        private const string Cell = "Cell";
        private const string CellId = "CellId";
        private const string Txrxmode = "TxRxMode";

        private readonly DbContext _context;
        public ConfigurationProcessService(DbContext dbContext)
        {
            _context = dbContext;
        }

        public List<CellConfigurationExtract> ExtractCellConfigurationObject(string folderPath, string dateTime)
        {
            try
            {
                var files = Directory.GetFiles(folderPath);

                var lstFileName = files.Where(x => x.EndsWith(dateTime, StringComparison.OrdinalIgnoreCase)).ToList();

                var result = new List<CellConfigurationExtract>();

                foreach (string xmlFile in lstFileName)
                {
                    if (!File.Exists(xmlFile)) continue;
                    using (XmlReader reader = XmlReader.Create(xmlFile))
                    {
                        while (reader.Read())
                        {
                            if (reader.Name.Equals(Cell)) //read node until <Cell>
                            {
                                CellConfigurationExtract cellConfig = new CellConfigurationExtract();

                                //Read following node <CellId>
                                reader.ReadToFollowing(CellId);

                                //The next is context of node <CellId>
                                reader.Read();

                                cellConfig.CellId = reader.Value;

                                //Read following node <TxTxMode>
                                reader.ReadToFollowing(Txrxmode);

                                //The next is context of node <TxRxMode>
                                reader.Read();

                                cellConfig.TxRxMode = reader.Value;

                                result.Add(cellConfig);

                            }
                        }
                    }
                }
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void SendCellConfigurationToStream(List<CellConfigurationExtract> data)
        {
            if (data==null) return;
            if (data.Count == 0) return;
            var eventHubClient = EventHubClient.CreateFromConnectionString(senderConfigurationConnectionString, senderConfigurationEventHub);
            foreach (var cellConfig in data)
            {
                eventHubClient.Send(new EventData(Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(cellConfig))));
            }
        }

        public void ConvertFileAndUploadToBlob(string folderPath, string dateTime,TextWriter log)
        {
            var files = Directory.GetFiles(folderPath);

            #region prepare header

            var str = new StringBuilder();
            //LocalCellId

            str.Append("LocalCellId,");


            //CellName

            str.Append("CellName,");


            //<CsgInd>0</CsgInd><!--False-->

            str.Append("CsgInd,");


            //<UlCyclicPrefix>0</UlCyclicPrefix><!--Normal-->

            str.Append("UlCyclicPrefix,");


            //<DlCyclicPrefix>0</DlCyclicPrefix><!--Normal-->

            str.Append("DlCyclicPrefix,");


            //FreqBand

            str.Append("FreqBand,");


            //<UlEarfcnCfgInd>0</UlEarfcnCfgInd><!--Notconfigure-->

            str.Append("UlEarfcnCfgInd,");


            //DlEarfcn

            str.Append("DlEarfcn,");


            //<UlBandWidth>5</UlBandWidth><!--20M-->

            str.Append("UlBandWidth,");


            //<DlBandWidth>5</DlBandWidth><!--20M-->

            str.Append("DlBandWidth,");


            //CellId

            str.Append("CellId,");


            //PhyCellId

            str.Append("PhyCellId,");


            //AdditionalSpectrumEmission

            str.Append("AdditionalSpectrumEmission,");


            //<CellActiveState>1</CellActiveState><!--Active-->

            str.Append("CellActiveState,");


            //<CellAdminState>0</CellAdminState><!--Unblock-->

            str.Append("CellAdminState,");


            //<FddTddInd>0</FddTddInd><!--FDD-->

            str.Append("FddTddInd,");


            //<CellSpecificOffset>15</CellSpecificOffset><!--0dB-->

            str.Append("CellSpecificOffset,");


            //<QoffsetFreq>15</QoffsetFreq><!--0dB-->

            str.Append("QoffsetFreq,");


            //RootSequenceIdx

            str.Append("RootSequenceIdx,");


            //<HighSpeedFlag>0</HighSpeedFlag><!--Lowspeedcellflag-->

            str.Append("HighSpeedFlag,");


            //PreambleFmt

            str.Append("PreambleFmt,");


            //CellRadius

            str.Append("CellRadius,");


            //<CustomizedBandWidthCfgInd>0</CustomizedBandWidthCfgInd><!--Notconfigure-->

            str.Append("CustomizedBandWidthCfgInd,");


            //<EmergencyAreaIdCfgInd>0</EmergencyAreaIdCfgInd><!--Notconfigure-->

            str.Append("EmergencyAreaIdCfgInd,");


            //<UePowerMaxCfgInd>0</UePowerMaxCfgInd><!--Notconfigure-->

            str.Append("UePowerMaxCfgInd,");


            //<MultiRruCellFlag>0</MultiRruCellFlag><!--False-->

            str.Append("MultiRruCellFlag,");


            //<CPRICompression>0</CPRICompression><!--NoCompression-->

            str.Append("CpriCompression,");


            //<AirCellFlag>0</AirCellFlag><!--False-->

            str.Append("AirCellFlag,");


            //<CrsPortNum>1</CrsPortNum><!--1port-->

            str.Append("CrsPortNum,");



            //<TxRxMode>0</TxRxMode><!--1T1R-->

            str.Append("TxRxMode,");


            //UserLabel

            str.Append("UserLabel,");


            //<WorkMode>0</WorkMode><!--Uplinkanddownlink-->

            str.Append("WorkMode,");


            //<EuCellStandbyMode>0</EuCellStandbyMode><!--Active-->

            str.Append("EuCellStandbyMode,");



            //CellSlaveBand

            str.Append("CellSlaveBand,");


            //CnOpSharingGroupId

            str.Append("CnOpSharingGroupId,");


            //<IntraFreqRanSharingInd>1</IntraFreqRanSharingInd><!--True-->

            str.Append("IntraFreqRanSharingInd,");



            //<IntraFreqAnrInd>1</IntraFreqAnrInd><!--ALLOWED-->

            str.Append("IntraFreqAnrInd,");


            //<CellScaleInd>0</CellScaleInd><!--MACRO-->

            str.Append("CellScaleInd,");


            //FreqPriorityForAnr

            str.Append("FreqPriorityForAnr,");


            //CellRadiusStartLocation

            str.Append("CellRadiusStartLocation,");


            //objId

            str.Append("ObjId,");


            str.Append("\r\n");
            log.WriteLine("complete header");
            #endregion
            
            var lstFileName = files.Where(x => x.EndsWith(dateTime, StringComparison.OrdinalIgnoreCase)).ToList();
            var configurations = new List<CellConfigurationExtract>();
             log.WriteLine("total file "+ lstFileName.Count);
            foreach (var file in lstFileName)
            {
                //convert xml to object
             
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.Load(file);
                if (xmlDoc.DocumentElement != null)
                {
                    XmlNodeList nodeList = xmlDoc.DocumentElement.GetElementsByTagName("Cell");
                    foreach (XmlNode node in nodeList)
                    {
                        var attributes = node.FirstChild;
                        var configurationModel = new CellConfigurationExtract();
                        try
                        {
                            var xmlElement = attributes["LocalCellId"];
                            if (xmlElement != null)
                                configurationModel.LocalCellId = xmlElement.InnerText;
                            var element = attributes["CellName"];
                            if (element != null)
                                configurationModel.CellName = element.InnerText;
                            var xmlElement1 = attributes["CsgInd"];
                            if (xmlElement1 != null)
                                configurationModel.CsgInd = xmlElement1.InnerText;
                            var element1 = attributes["UlCyclicPrefix"];
                            if (element1 != null)
                                configurationModel.UlCyclicPrefix = element1.InnerText;
                            var xmlElement2 = attributes["DlCyclicPrefix"];
                            if (xmlElement2 != null)
                                configurationModel.DlCyclicPrefix = xmlElement2.InnerText;

                            configurationModel.FreqBand = attributes["FreqBand"]?.InnerText ?? "";
                            configurationModel.UlEarfcnCfgInd = attributes["UlEarfcnCfgInd"]?.InnerText ?? "";
                            configurationModel.DlEarfcn = attributes["DlEarfcn"]?.InnerText ?? "";
                            configurationModel.UlBandWidth = attributes["UlBandWidth"]?.InnerText ?? "";
                            configurationModel.DlBandWidth = attributes["DlBandWidth"]?.InnerText ?? "";
                            configurationModel.CellId = attributes["CellId"]?.InnerText ?? "";
                            configurationModel.PhyCellId = attributes["PhyCellId"]?.InnerText ?? "";
                            configurationModel.AdditionalSpectrumEmission = attributes["AdditionalSpectrumEmission"]?.InnerText ?? "";
                            configurationModel.CellActiveState = attributes["CellActiveState"]?.InnerText ?? "";
                            configurationModel.CellAdminState = attributes["CellAdminState"]?.InnerText ?? "";
                            configurationModel.FddTddInd = attributes["FddTddInd"]?.InnerText ?? "";
                            configurationModel.CellSpecificOffset = attributes["CellSpecificOffset"]?.InnerText ?? "";
                            configurationModel.QoffsetFreq = attributes["QoffsetFreq"]?.InnerText ?? "";
                            configurationModel.RootSequenceIdx = attributes["RootSequenceIdx"]?.InnerText ?? "";
                            configurationModel.HighSpeedFlag = attributes["HighSpeedFlag"]?.InnerText ?? "";
                            configurationModel.PreambleFmt = attributes["PreambleFmt"]?.InnerText ?? "";
                            configurationModel.CellRadius = attributes["CellRadius"]?.InnerText ?? "";
                            configurationModel.CustomizedBandWidthCfgInd = attributes["CustomizedBandWidthCfgInd"]?.InnerText ?? "";
                            configurationModel.EmergencyAreaIdCfgInd = attributes["EmergencyAreaIdCfgInd"]?.InnerText ?? "";
                            configurationModel.UePowerMaxCfgInd = attributes["UePowerMaxCfgInd"]?.InnerText ?? "";
                            configurationModel.MultiRruCellFlag = attributes["MultiRruCellFlag"]?.InnerText ?? "";
                            configurationModel.CpriCompression = attributes["CPRICompression"]?.InnerText ?? "";
                            configurationModel.AirCellFlag = attributes["AirCellFlag"]?.InnerText ?? "";
                            configurationModel.CrsPortNum = attributes["CrsPortNum"]?.InnerText ?? "";
                            configurationModel.TxRxMode = attributes["TxRxMode"]?.InnerText ?? "";
                            configurationModel.UserLabel = attributes["UserLabel"]?.InnerText ?? "";
                            configurationModel.WorkMode = attributes["WorkMode"]?.InnerText ?? "";
                            configurationModel.EuCellStandbyMode = attributes["EuCellStandbyMode"]?.InnerText ?? "";
                            configurationModel.CellSlaveBand = attributes["CellSlaveBand"]?.InnerText ?? "";
                            configurationModel.CnOpSharingGroupId = attributes["CnOpSharingGroupId"]?.InnerText ?? "";
                            configurationModel.IntraFreqRanSharingInd = attributes["IntraFreqRanSharingInd"]?.InnerText ?? "";
                            configurationModel.IntraFreqAnrInd = attributes["IntraFreqAnrInd"]?.InnerText ?? "";
                            configurationModel.CellScaleInd = attributes["CellScaleInd"]?.InnerText ?? "";
                            configurationModel.FreqPriorityForAnr = attributes["FreqPriorityForAnr"]?.InnerText ?? "";
                            configurationModel.CellRadiusStartLocation = attributes["CellRadiusStartLocation"]?.InnerText ?? "";
                            configurationModel.ObjId = attributes["objId"]?.InnerText ?? "";
                        }
                        catch (Exception ex)
                        {
                            
                            log.WriteLine("null obj here");
                        }
                        if(string.IsNullOrEmpty(configurationModel.CellName)) continue;
                        
                        if (configurations.FirstOrDefault(p => p.CellName == configurationModel.CellName) == null)
                        {
                            configurations.Add(configurationModel);
                        }
                    }
                }
            }
            log.WriteLine("complete parse");
            #region bind data

            foreach (var item in configurations)
            {
                //LocalCellId

                str.Append("\"" + item.LocalCellId + "\",");


                //CellName

                str.Append("\"" + item.CellName + "\",");


                //<CsgInd>0</CsgInd><!--False-->

                str.Append("\"" + item.CsgInd + "\",");


                //<UlCyclicPrefix>0</UlCyclicPrefix><!--Normal-->

                str.Append("\"" + item.UlCyclicPrefix + "\",");


                //<DlCyclicPrefix>0</DlCyclicPrefix><!--Normal-->

                str.Append("\"" + item.DlCyclicPrefix + "\",");


                //FreqBand

                str.Append("\"" + item.FreqBand + "\",");


                //<UlEarfcnCfgInd>0</UlEarfcnCfgInd><!--Notconfigure-->

                str.Append("\"" + item.UlEarfcnCfgInd + "\",");


                //DlEarfcn

                str.Append("\"" + item.DlEarfcn + "\",");


                //<UlBandWidth>5</UlBandWidth><!--20M-->

                str.Append("\"" + item.UlBandWidth + "\",");


                //<DlBandWidth>5</DlBandWidth><!--20M-->

                str.Append("\"" + item.DlBandWidth + "\",");


                //CellId

                str.Append("\"" + item.CellId + "\",");


                //PhyCellId

                str.Append("\"" + item.PhyCellId + "\",");


                //AdditionalSpectrumEmission

                str.Append("\"" + item.AdditionalSpectrumEmission + "\",");


                //<CellActiveState>1</CellActiveState><!--Active-->

                str.Append("\"" + item.CellActiveState + "\",");


                //<CellAdminState>0</CellAdminState><!--Unblock-->

                str.Append("\"" + item.CellAdminState + "\",");


                //<FddTddInd>0</FddTddInd><!--FDD-->

                str.Append("\"" + item.FddTddInd + "\",");


                //<CellSpecificOffset>15</CellSpecificOffset><!--0dB-->

                str.Append("\"" + item.CellSpecificOffset + "\",");


                //<QoffsetFreq>15</QoffsetFreq><!--0dB-->

                str.Append("\"" + item.QoffsetFreq + "\",");


                //RootSequenceIdx

                str.Append("\"" + item.RootSequenceIdx + "\",");


                //<HighSpeedFlag>0</HighSpeedFlag><!--Lowspeedcellflag-->

                str.Append("\"" + item.HighSpeedFlag + "\",");


                //PreambleFmt

                str.Append("\"" + item.PreambleFmt + "\",");


                //CellRadius

                str.Append("\"" + item.CellRadius + "\",");


                //<CustomizedBandWidthCfgInd>0</CustomizedBandWidthCfgInd><!--Notconfigure-->

                str.Append("\"" + item.CustomizedBandWidthCfgInd + "\",");


                //<EmergencyAreaIdCfgInd>0</EmergencyAreaIdCfgInd><!--Notconfigure-->

                str.Append("\"" + item.EmergencyAreaIdCfgInd + "\",");


                //<UePowerMaxCfgInd>0</UePowerMaxCfgInd><!--Notconfigure-->

                str.Append("\"" + item.UePowerMaxCfgInd + "\",");


                //<MultiRruCellFlag>0</MultiRruCellFlag><!--False-->

                str.Append("\"" + item.MultiRruCellFlag + "\",");


                //<CPRICompression>0</CPRICompression><!--NoCompression-->

                str.Append("\"" + item.CpriCompression + "\",");


                //<AirCellFlag>0</AirCellFlag><!--False-->

                str.Append("\"" + item.AirCellFlag + "\",");


                //<CrsPortNum>1</CrsPortNum><!--1port-->

                str.Append("\"" + item.CrsPortNum + "\",");



                //<TxRxMode>0</TxRxMode><!--1T1R-->

                str.Append("\"" + item.TxRxMode + "\",");


                //UserLabel

                str.Append("\"" + item.UserLabel + "\",");


                //<WorkMode>0</WorkMode><!--Uplinkanddownlink-->

                str.Append("\"" + item.WorkMode + "\",");


                //<EuCellStandbyMode>0</EuCellStandbyMode><!--Active-->

                str.Append("\"" + item.EuCellStandbyMode + "\",");



                //CellSlaveBand

                str.Append("\"" + item.CellSlaveBand + "\",");


                //CnOpSharingGroupId

                str.Append("\"" + item.CnOpSharingGroupId + "\",");


                //<IntraFreqRanSharingInd>1</IntraFreqRanSharingInd><!--True-->

                str.Append("\"" + item.IntraFreqRanSharingInd + "\",");



                //<IntraFreqAnrInd>1</IntraFreqAnrInd><!--ALLOWED-->

                str.Append("\"" + item.IntraFreqAnrInd + "\",");


                //<CellScaleInd>0</CellScaleInd><!--MACRO-->

                str.Append("\"" + item.CellScaleInd + "\",");


                //FreqPriorityForAnr

                str.Append("\"" + item.FreqPriorityForAnr + "\",");


                //CellRadiusStartLocation

                str.Append("\"" + item.CellRadiusStartLocation + "\",");
                //objId
                str.Append("\"" + item.ObjId + "\",");
                str.Append("\r\n");
            }
            log.WriteLine("complete binding");
            #endregion

            FileStream fs = new FileStream(folderPath+"configuration.csv", FileMode.Create, FileAccess.ReadWrite);
            BinaryWriter bw = new BinaryWriter(fs);
            bw.Write(Encoding.UTF8.GetBytes(str.ToString()));
            bw.Close();
            log.WriteLine("complete saving");

            // Retrieve reference to a blob
            var blobContainer = AzureHelper.AlarmCloudBlobContainer;
       

            var blob = blobContainer.GetBlockBlobReference("configuration.csv");

            // Set the blob content type
            blob.Properties.ContentType = "text/csv";

            // Upload file into blob storage, basically copying it from local disk into Azure
            using (var fs2 = File.OpenRead(folderPath + "configuration.csv"))
            {
                blob.UploadFromStream(fs2);
            }

        }


        public void ConvertFileAndUploadToBlob(Stream stream)
        {

            #region prepare header

            var str = new StringBuilder();
            //LocalCellId

            str.Append("LocalCellId,");


            //CellName

            str.Append("CellName,");


            //<CsgInd>0</CsgInd><!--False-->

            str.Append("CsgInd,");


            //<UlCyclicPrefix>0</UlCyclicPrefix><!--Normal-->

            str.Append("UlCyclicPrefix,");


            //<DlCyclicPrefix>0</DlCyclicPrefix><!--Normal-->

            str.Append("DlCyclicPrefix,");


            //FreqBand

            str.Append("FreqBand,");


            //<UlEarfcnCfgInd>0</UlEarfcnCfgInd><!--Notconfigure-->

            str.Append("UlEarfcnCfgInd,");


            //DlEarfcn

            str.Append("DlEarfcn,");


            //<UlBandWidth>5</UlBandWidth><!--20M-->

            str.Append("UlBandWidth,");


            //<DlBandWidth>5</DlBandWidth><!--20M-->

            str.Append("DlBandWidth,");


            //CellId

            str.Append("CellId,");


            //PhyCellId

            str.Append("PhyCellId,");


            //AdditionalSpectrumEmission

            str.Append("AdditionalSpectrumEmission,");


            //<CellActiveState>1</CellActiveState><!--Active-->

            str.Append("CellActiveState,");


            //<CellAdminState>0</CellAdminState><!--Unblock-->

            str.Append("CellAdminState,");


            //<FddTddInd>0</FddTddInd><!--FDD-->

            str.Append("FddTddInd,");


            //<CellSpecificOffset>15</CellSpecificOffset><!--0dB-->

            str.Append("CellSpecificOffset,");


            //<QoffsetFreq>15</QoffsetFreq><!--0dB-->

            str.Append("QoffsetFreq,");


            //RootSequenceIdx

            str.Append("RootSequenceIdx,");


            //<HighSpeedFlag>0</HighSpeedFlag><!--Lowspeedcellflag-->

            str.Append("HighSpeedFlag,");


            //PreambleFmt

            str.Append("PreambleFmt,");


            //CellRadius

            str.Append("CellRadius,");


            //<CustomizedBandWidthCfgInd>0</CustomizedBandWidthCfgInd><!--Notconfigure-->

            str.Append("CustomizedBandWidthCfgInd,");


            //<EmergencyAreaIdCfgInd>0</EmergencyAreaIdCfgInd><!--Notconfigure-->

            str.Append("EmergencyAreaIdCfgInd,");


            //<UePowerMaxCfgInd>0</UePowerMaxCfgInd><!--Notconfigure-->

            str.Append("UePowerMaxCfgInd,");


            //<MultiRruCellFlag>0</MultiRruCellFlag><!--False-->

            str.Append("MultiRruCellFlag,");


            //<CPRICompression>0</CPRICompression><!--NoCompression-->

            str.Append("CpriCompression,");


            //<AirCellFlag>0</AirCellFlag><!--False-->

            str.Append("AirCellFlag,");


            //<CrsPortNum>1</CrsPortNum><!--1port-->

            str.Append("CrsPortNum,");



            //<TxRxMode>0</TxRxMode><!--1T1R-->

            str.Append("TxRxMode,");


            //UserLabel

            str.Append("UserLabel,");


            //<WorkMode>0</WorkMode><!--Uplinkanddownlink-->

            str.Append("WorkMode,");


            //<EuCellStandbyMode>0</EuCellStandbyMode><!--Active-->

            str.Append("EuCellStandbyMode,");



            //CellSlaveBand

            str.Append("CellSlaveBand,");


            //CnOpSharingGroupId

            str.Append("CnOpSharingGroupId,");


            //<IntraFreqRanSharingInd>1</IntraFreqRanSharingInd><!--True-->

            str.Append("IntraFreqRanSharingInd,");



            //<IntraFreqAnrInd>1</IntraFreqAnrInd><!--ALLOWED-->

            str.Append("IntraFreqAnrInd,");


            //<CellScaleInd>0</CellScaleInd><!--MACRO-->

            str.Append("CellScaleInd,");


            //FreqPriorityForAnr

            str.Append("FreqPriorityForAnr,");


            //CellRadiusStartLocation

            str.Append("CellRadiusStartLocation,");


            //objId

            str.Append("ObjId,");


            str.Append("\r\n");

            #endregion

            //convert xml to object

            List<CellConfigurationExtract> configurations = new List<CellConfigurationExtract>();
            
            XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.Load(stream);
                if (xmlDoc.DocumentElement != null)
                {
                    XmlNodeList nodeList = xmlDoc.DocumentElement.GetElementsByTagName("Cell");
                    foreach (XmlNode node in nodeList)
                    {
                    
                    var attributes = node.FirstChild;
                       
                        try
                        {
                        var configurationModel = new CellConfigurationExtract();

                        var xmlElement = attributes["LocalCellId"];
                            if (xmlElement != null)
                                configurationModel.LocalCellId = xmlElement.InnerText;
                            var element = attributes["CellName"];
                            if (element != null)
                                configurationModel.CellName = element.InnerText;
                            //var xmlElement1 = attributes["CsgInd"];
                            //if (xmlElement1 != null)
                            //    configurationModel.CsgInd = xmlElement1.InnerText;
                            //var element1 = attributes["UlCyclicPrefix"];
                            //if (element1 != null)
                            //    configurationModel.UlCyclicPrefix = element1.InnerText;
                            //var xmlElement2 = attributes["DlCyclicPrefix"];
                            //if (xmlElement2 != null)
                            //    configurationModel.DlCyclicPrefix = xmlElement2.InnerText;

                            //configurationModel.FreqBand = attributes["FreqBand"]?.InnerText ?? "";
                            //configurationModel.UlEarfcnCfgInd = attributes["UlEarfcnCfgInd"]?.InnerText ?? "";
                            //configurationModel.DlEarfcn = attributes["DlEarfcn"]?.InnerText ?? "";
                            //configurationModel.UlBandWidth = attributes["UlBandWidth"]?.InnerText ?? "";
                            //configurationModel.DlBandWidth = attributes["DlBandWidth"]?.InnerText ?? "";
                            //configurationModel.CellId = attributes["CellId"]?.InnerText ?? "";
                            //configurationModel.PhyCellId = attributes["PhyCellId"]?.InnerText ?? "";
                            //configurationModel.AdditionalSpectrumEmission = attributes["AdditionalSpectrumEmission"]?.InnerText ?? "";
                            //configurationModel.CellActiveState = attributes["CellActiveState"]?.InnerText ?? "";
                            //configurationModel.CellAdminState = attributes["CellAdminState"]?.InnerText ?? "";
                            //configurationModel.FddTddInd = attributes["FddTddInd"]?.InnerText ?? "";
                            //configurationModel.CellSpecificOffset = attributes["CellSpecificOffset"]?.InnerText ?? "";
                            //configurationModel.QoffsetFreq = attributes["QoffsetFreq"]?.InnerText ?? "";
                            //configurationModel.RootSequenceIdx = attributes["RootSequenceIdx"]?.InnerText ?? "";
                            //configurationModel.HighSpeedFlag = attributes["HighSpeedFlag"]?.InnerText ?? "";
                            //configurationModel.PreambleFmt = attributes["PreambleFmt"]?.InnerText ?? "";
                            //configurationModel.CellRadius = attributes["CellRadius"]?.InnerText ?? "";
                            //configurationModel.CustomizedBandWidthCfgInd = attributes["CustomizedBandWidthCfgInd"]?.InnerText ?? "";
                            //configurationModel.EmergencyAreaIdCfgInd = attributes["EmergencyAreaIdCfgInd"]?.InnerText ?? "";
                            //configurationModel.UePowerMaxCfgInd = attributes["UePowerMaxCfgInd"]?.InnerText ?? "";
                            //configurationModel.MultiRruCellFlag = attributes["MultiRruCellFlag"]?.InnerText ?? "";
                            //configurationModel.CpriCompression = attributes["CPRICompression"]?.InnerText ?? "";
                            //configurationModel.AirCellFlag = attributes["AirCellFlag"]?.InnerText ?? "";
                            //configurationModel.CrsPortNum = attributes["CrsPortNum"]?.InnerText ?? "";
                            configurationModel.TxRxMode = attributes["TxRxMode"]?.InnerText ?? "";
                            //configurationModel.UserLabel = attributes["UserLabel"]?.InnerText ?? "";
                            //configurationModel.WorkMode = attributes["WorkMode"]?.InnerText ?? "";
                            //configurationModel.EuCellStandbyMode = attributes["EuCellStandbyMode"]?.InnerText ?? "";
                            //configurationModel.CellSlaveBand = attributes["CellSlaveBand"]?.InnerText ?? "";
                            //configurationModel.CnOpSharingGroupId = attributes["CnOpSharingGroupId"]?.InnerText ?? "";
                            //configurationModel.IntraFreqRanSharingInd = attributes["IntraFreqRanSharingInd"]?.InnerText ?? "";
                            //configurationModel.IntraFreqAnrInd = attributes["IntraFreqAnrInd"]?.InnerText ?? "";
                            //configurationModel.CellScaleInd = attributes["CellScaleInd"]?.InnerText ?? "";
                            //configurationModel.FreqPriorityForAnr = attributes["FreqPriorityForAnr"]?.InnerText ?? "";
                            //configurationModel.CellRadiusStartLocation = attributes["CellRadiusStartLocation"]?.InnerText ?? "";
                            //configurationModel.ObjId = attributes["objId"]?.InnerText ?? "";


                            configurations.Add(configurationModel);
                        }
                        catch (Exception ex)
                        {

                        }
                        
                    }
                }


            foreach (var configurationModel in configurations)
            {
                var item = configurationModel;
                #region bind data

                //LocalCellId

                str.Append("\"" + item.LocalCellId + "\",");


                //CellName

                str.Append("\"" + item.CellName + "\",");


                //<CsgInd>0</CsgInd><!--False-->

                str.Append("\"" + item.CsgInd + "\",");


                //<UlCyclicPrefix>0</UlCyclicPrefix><!--Normal-->

                str.Append("\"" + item.UlCyclicPrefix + "\",");


                //<DlCyclicPrefix>0</DlCyclicPrefix><!--Normal-->

                str.Append("\"" + item.DlCyclicPrefix + "\",");


                //FreqBand

                str.Append("\"" + item.FreqBand + "\",");


                //<UlEarfcnCfgInd>0</UlEarfcnCfgInd><!--Notconfigure-->

                str.Append("\"" + item.UlEarfcnCfgInd + "\",");


                //DlEarfcn

                str.Append("\"" + item.DlEarfcn + "\",");


                //<UlBandWidth>5</UlBandWidth><!--20M-->

                str.Append("\"" + item.UlBandWidth + "\",");


                //<DlBandWidth>5</DlBandWidth><!--20M-->

                str.Append("\"" + item.DlBandWidth + "\",");


                //CellId

                str.Append("\"" + item.CellId + "\",");


                //PhyCellId

                str.Append("\"" + item.PhyCellId + "\",");


                //AdditionalSpectrumEmission

                str.Append("\"" + item.AdditionalSpectrumEmission + "\",");


                //<CellActiveState>1</CellActiveState><!--Active-->

                str.Append("\"" + item.CellActiveState + "\",");


                //<CellAdminState>0</CellAdminState><!--Unblock-->

                str.Append("\"" + item.CellAdminState + "\",");


                //<FddTddInd>0</FddTddInd><!--FDD-->

                str.Append("\"" + item.FddTddInd + "\",");


                //<CellSpecificOffset>15</CellSpecificOffset><!--0dB-->

                str.Append("\"" + item.CellSpecificOffset + "\",");


                //<QoffsetFreq>15</QoffsetFreq><!--0dB-->

                str.Append("\"" + item.QoffsetFreq + "\",");


                //RootSequenceIdx

                str.Append("\"" + item.RootSequenceIdx + "\",");


                //<HighSpeedFlag>0</HighSpeedFlag><!--Lowspeedcellflag-->

                str.Append("\"" + item.HighSpeedFlag + "\",");


                //PreambleFmt

                str.Append("\"" + item.PreambleFmt + "\",");


                //CellRadius

                str.Append("\"" + item.CellRadius + "\",");


                //<CustomizedBandWidthCfgInd>0</CustomizedBandWidthCfgInd><!--Notconfigure-->

                str.Append("\"" + item.CustomizedBandWidthCfgInd + "\",");


                //<EmergencyAreaIdCfgInd>0</EmergencyAreaIdCfgInd><!--Notconfigure-->

                str.Append("\"" + item.EmergencyAreaIdCfgInd + "\",");


                //<UePowerMaxCfgInd>0</UePowerMaxCfgInd><!--Notconfigure-->

                str.Append("\"" + item.UePowerMaxCfgInd + "\",");


                //<MultiRruCellFlag>0</MultiRruCellFlag><!--False-->

                str.Append("\"" + item.MultiRruCellFlag + "\",");


                //<CPRICompression>0</CPRICompression><!--NoCompression-->

                str.Append("\"" + item.CpriCompression + "\",");


                //<AirCellFlag>0</AirCellFlag><!--False-->

                str.Append("\"" + item.AirCellFlag + "\",");


                //<CrsPortNum>1</CrsPortNum><!--1port-->

                str.Append("\"" + item.CrsPortNum + "\",");



                //<TxRxMode>0</TxRxMode><!--1T1R-->

                str.Append("\"" + item.TxRxMode + "\",");


                //UserLabel

                str.Append("\"" + item.UserLabel + "\",");


                //<WorkMode>0</WorkMode><!--Uplinkanddownlink-->

                str.Append("\"" + item.WorkMode + "\",");


                //<EuCellStandbyMode>0</EuCellStandbyMode><!--Active-->

                str.Append("\"" + item.EuCellStandbyMode + "\",");



                //CellSlaveBand

                str.Append("\"" + item.CellSlaveBand + "\",");


                //CnOpSharingGroupId

                str.Append("\"" + item.CnOpSharingGroupId + "\",");


                //<IntraFreqRanSharingInd>1</IntraFreqRanSharingInd><!--True-->

                str.Append("\"" + item.IntraFreqRanSharingInd + "\",");



                //<IntraFreqAnrInd>1</IntraFreqAnrInd><!--ALLOWED-->

                str.Append("\"" + item.IntraFreqAnrInd + "\",");


                //<CellScaleInd>0</CellScaleInd><!--MACRO-->

                str.Append("\"" + item.CellScaleInd + "\",");


                //FreqPriorityForAnr

                str.Append("\"" + item.FreqPriorityForAnr + "\",");


                //CellRadiusStartLocation

                str.Append("\"" + item.CellRadiusStartLocation + "\",");
                //objId
                str.Append("\"" + item.ObjId + "\",");
                str.Append("\r\n");

                #endregion
            }

            var path = "/App_Data/CellConfiguration/";
           

            if (HostingEnvironment.IsHosted)
            {
                //hosted
                path = HostingEnvironment.MapPath(path);
            }
            else
            {
                //not hosted. For example, run in unit tests
                string baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
                path = path.Replace("~/", "").TrimStart('/').Replace('/', '\\');
                path = Path.Combine(baseDirectory, path);
            }

            FileStream fs = new FileStream(path + "configurationtest.csv", FileMode.Create, FileAccess.ReadWrite);
            BinaryWriter bw = new BinaryWriter(fs);
            bw.Write(Encoding.UTF8.GetBytes(str.ToString()));
            bw.Close();

            // Retrieve reference to a blob
            var blobContainer = AzureHelper.AlarmCloudBlobContainerTest;


            var blob = blobContainer.GetBlockBlobReference("configuration.csv");

            // Set the blob content type
            blob.Properties.ContentType = "text/csv";

            // Upload file into blob storage, basically copying it from local disk into Azure
            using (var fs2 = File.OpenRead(path + "configurationtest.csv"))
            {
                blob.UploadFromStream(fs2);
            }

        }

      

        private void PrepareDataForConfiguration(StringBuilder str ,string testId,List<CellConfigurationExtract> configurations)
        {
           foreach (var configurationModel in configurations)
            {
                var item = configurationModel;

                #region bind data

                str.Append("\"" + testId + "\",");
                //LocalCellId

                str.Append("\"" + item.LocalCellId + "\",");


                //CellName

                str.Append("\"" + item.CellName +  "\",");


                //<TxRxMode>0</TxRxMode><!--1T1R-->

                str.Append("\"" + item.TxRxMode + "\",");


                str.Append("\r\n");

                #endregion
            }
        }

        private void PrepareHeaderForConfiguration(StringBuilder str)
        {
            #region prepare header

            str.Append("TestId,");
            //LocalCellId

            str.Append("LocalCellId,");
            //CellName

            str.Append("CellName,");


            str.Append("TxRxMode,");


            str.Append("\r\n");

            #endregion
        }

        private  List<CellConfigurationExtract> ExtractConfigurationFromXmls(Stream stream)
        {
            var configurations = new List<CellConfigurationExtract>();

            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load(stream);
            if (xmlDoc.DocumentElement != null)
            {
                XmlNodeList nodeList = xmlDoc.DocumentElement.GetElementsByTagName("Cell");
                foreach (XmlNode node in nodeList)
                {
                    var attributes = node.FirstChild;

                    try
                    {
                        var configurationModel = new CellConfigurationExtract();

                        var xmlElement = attributes["LocalCellId"];
                        if (xmlElement != null)
                            configurationModel.LocalCellId = xmlElement.InnerText;
                        var element = attributes["CellName"];
                        if (element != null)
                            configurationModel.CellName = element.InnerText;

                        configurationModel.TxRxMode = attributes["TxRxMode"]?.InnerText ?? "";


                        configurations.Add(configurationModel);
                    }
                    catch (Exception ex)
                    {
                    }
                }
            }
            return configurations;
        }

       
        public void ConvertFileAndUploadToBlobForTesting(List<CellConfigurationExtract> allConfiguration, string testId)
        {
            var finalStringBuilder = new StringBuilder();
            
            //prepare header
            PrepareHeaderForConfiguration(finalStringBuilder);
            //prepare data
            PrepareDataForConfiguration(finalStringBuilder,testId, allConfiguration);

            var path = "/App_Data/CellConfiguration/";


            if (HostingEnvironment.IsHosted)
            {
                //hosted
                path = HostingEnvironment.MapPath(path);
            }
            else
            {
                //not hosted. For example, run in unit tests
                string baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
                path = path.Replace("~/", "").TrimStart('/').Replace('/', '\\');
                path = Path.Combine(baseDirectory, path);
            }

            FileStream fs = new FileStream(path + testId + "_configuration.csv", FileMode.Create, FileAccess.ReadWrite);
            BinaryWriter bw = new BinaryWriter(fs);
            bw.Write(Encoding.UTF8.GetBytes(finalStringBuilder.ToString()));
            bw.Close();
            for (var i = 0; i < 3; i++)
            {
                // Retrieve reference to a blob
                var blobContainer = AzureHelper.AlarmCloudBlobContainerTest;

                var datetime = DateTime.UtcNow.AddMinutes(i);
                var blobName = string.Format("{0}/{1}/configuration.csv", datetime.ToString("dd-MM-yyyy"), datetime.ToString("HH-mm"));
                var blob = blobContainer.GetBlockBlobReference(blobName);
                // Set the blob content type
                blob.Properties.ContentType = "text/csv";

                // Upload file into blob storage, basically copying it from local disk into Azure
                using (var fs2 = File.OpenRead(path + testId + "_configuration.csv"))
                {
                    blob.UploadFromStream(fs2);
                }
            }

        }

        public List<CellConfigurationExtract> ExtractConfigurationForTesting(List<string> configurationFilePaths, string testId)
        {
            var allConfiguration = new List<CellConfigurationExtract>();
            foreach (var filePath in configurationFilePaths)
            {
                var stream = File.OpenRead(filePath);
                allConfiguration.AddRange(ExtractConfigurationFromXmls(stream));
            }
            return allConfiguration;
        }

        public List<CellConfigurationForPwrSwitchAndAtten> PrepareConfigurationForPwrSwitchAndAtten(string folderPath, DateTime dateTime, TextWriter log)
        {
            var results = new List<CellConfigurationForPwrSwitchAndAtten>();
            var listConfigurationForForPwrSwitchAndAttenExtract = new List<CellConfigurationExtractForSecondQuery>();

            try
            {
                var files = Directory.GetFiles(folderPath);

                var lstFileName = files.Where(x => x.EndsWith(string.Format("{0}.xml", dateTime.ToString("ddMMyyyy")) , StringComparison.OrdinalIgnoreCase)).ToList();

                Trace.TraceError("step 0 . number of XML get: " + lstFileName.Count);
                var sw10 = new Stopwatch();
                sw10.Start();
                foreach (string xmlFile in lstFileName)
                {
                    if (!File.Exists(xmlFile)) continue;
                    var sw100 = new Stopwatch();
                    sw100.Start();
                    var listWillAdd = ExtractListConfigurationForSecondQuery(xmlFile);
                    listConfigurationForForPwrSwitchAndAttenExtract.AddRange(listWillAdd);
                    sw100.Stop();
                    Trace.TraceError("step 1 .1.1 time " + sw100.ElapsedMilliseconds);

                }
                //convert extract to list entity
                sw10.Stop();
                Trace.TraceError("step 1 . number of extract configuration get: " + listConfigurationForForPwrSwitchAndAttenExtract.Count + " time " + sw10.ElapsedMilliseconds);
                var sw11 = new Stopwatch();
                sw11.Start();
                foreach (var extractConfiguration in listConfigurationForForPwrSwitchAndAttenExtract)
                {
                    results.AddRange(extractConfiguration.RxBranchAndAntennaPortValues.Select(pairValue => new CellConfigurationForPwrSwitchAndAtten()
                    {
                        CellName = extractConfiguration.CellName,
                        CnSrnSnRn = pairValue.CombineValue,
                        ATTEN = pairValue.ATTEN,
                        PWRSWITCH = pairValue.POWERSWITCH,
                        CreatedDateUtc = dateTime
                    }));
                }
                sw11.Stop();
                Trace.TraceError("number of configuration get: " + results.Count + " time " + sw11.ElapsedMilliseconds);

                var sw= new Stopwatch();
                sw.Start();
                //SaveToDatabaseForConfigurationOfPwrSwitchAndAtten(results);
                sw.Stop();
                Trace.TraceError("time for process CellConfigurationForPwrSwitchAndAtten " + sw.ElapsedMilliseconds);

                var sw1 = new Stopwatch();
                sw1.Start();
                //SaveToDatabaseForConfigurationOfSecondQuery(dateTime, dateTime.AddDays(-1));
                Trace.TraceError("time for process second query " + sw1.ElapsedMilliseconds);

                sw1.Stop();
               
                //prepare data for configuration on 2nd query

                return results;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void SaveToDatabaseForConfigurationOfPwrSwitchAndAtten(List<CellConfigurationForPwrSwitchAndAtten> configurations)
        {
            if (configurations == null || !configurations.Any()) return;
            string constr = ConfigurationManager.ConnectionStrings["AmsContext"].ConnectionString;
            var sb = new StringBuilder();
            sb.Append("INSERT INTO [CellConfigurationForPwrSwitchAndAtten] ( [Id], " +
                      " [CellName], " +
                      " [CnSrnSnRn], " +
                      
                      " [ATTEN], " +
                      " [PWRSWITCH], " +
                      " [CreatedDateUtc] " +
                      " ) VALUES ");
            for (var i = 1; i <= configurations.Count(); i++)
            {
                var configuration = configurations[i-1];
                if (i % 1000 == 0)
                {
                    sb.Append(string.Format("('{0}','{1}','{2}','{3}','{4}','{5}')", configuration.Id,
                   configuration.CellName,configuration.CnSrnSnRn,configuration.ATTEN,configuration.PWRSWITCH,configuration.CreatedDateUtc.ToString("yyyy-MM-dd'T'HH:mm:ss.FFF'Z'")));
                }
                else
                {
                    sb.Append(string.Format("('{0}','{1}','{2}','{3}','{4}','{5}'),", configuration.Id,
                   configuration.CellName, configuration.CnSrnSnRn, configuration.ATTEN, configuration.PWRSWITCH, configuration.CreatedDateUtc.ToString("yyyy-MM-dd'T'HH:mm:ss.FFF'Z'")));
                }


                if (i % 1000 == 0)
                {
                    //process then reset
                    using (SqlConnection connection = new SqlConnection(constr))
                    {
                        connection.Open();
                        SqlCommand cmd = new SqlCommand(sb.ToString(), connection);
                        var sw1 = new Stopwatch();
                        sw1.Start();
                        cmd.ExecuteNonQuery();
                        sw1.Stop();
                        Trace.TraceError("time for insert 1k records:"+ sw1.ElapsedMilliseconds);
                        
                    }
                    sb = new StringBuilder();
                    if (i < configurations.Count())
                        sb.Append("INSERT INTO [CellConfigurationForPwrSwitchAndAtten] ( [Id], " +
                      " [CellName], " +
                      " [CnSrnSnRn], " +
                      " [PWRSWITCH], " +
                      " [ATTEN], " +
                      " [CreatedDateUtc] " +
                      " ) VALUES ");
                }

            }


            using (SqlConnection connection = new SqlConnection(constr))
            {
                connection.Open();

                SqlCommand cmd = new SqlCommand(sb.ToString().TrimEnd(','), connection);
                
                var sw2 = new Stopwatch();
                sw2.Start();
                cmd.ExecuteNonQuery();
                sw2.Stop();
                Trace.TraceError("time for insert last 1k records:" + sw2.ElapsedMilliseconds);
            }
        }

        private void SaveToDatabaseForConfigurationOfSecondQuery(DateTime today,DateTime yesterday)
        {
            try
            {
                _context.Database.ExecuteSqlCommand("PrepareConfigurationDataForSecondQuery @startdate, @enddate", 
                    new SqlParameter("@startdate", today.ToString("yyyy-MM-dd HH:mm:ss.FFF")),
                    new SqlParameter("@enddate", yesterday.ToString("yyyy-MM-dd HH:mm:ss.FFF")));

            }
            catch (Exception ex)
            {
                
                throw ex;
            }

            }
        private  List<CellConfigurationExtractForSecondQuery> ExtractListConfigurationForSecondQuery(string filePath)
        {
            var result = new List<CellConfigurationExtractForSecondQuery>();
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load(filePath);
            if (xmlDoc.DocumentElement != null)
            {
                #region get cell

                XmlNodeList nodeList = xmlDoc.DocumentElement.GetElementsByTagName("Cell");
                foreach (XmlNode node in nodeList)
                {
                    //example of <Cell>

                    //<attributes>
                    //	<LocalCellId>1</LocalCellId>
                    //	<CellName>202975_Rhodes_MV_L18A_1</CellName>
                    //	<CsgInd>0</CsgInd><!--False-->
                    //	<UlCyclicPrefix>0</UlCyclicPrefix><!--Normal-->
                    //	<DlCyclicPrefix>0</DlCyclicPrefix><!--Normal-->
                    //	<FreqBand>3</FreqBand>
                    //	<UlEarfcnCfgInd>0</UlEarfcnCfgInd><!--Not configure-->
                    //	<DlEarfcn>1550</DlEarfcn>
                    //	<UlBandWidth>5</UlBandWidth><!--20M-->
                    //	<DlBandWidth>5</DlBandWidth><!--20M-->
                    //	<CellId>11</CellId>
                    //	<PhyCellId>156</PhyCellId>
                    //	<AdditionalSpectrumEmission>1</AdditionalSpectrumEmission>
                    //	<CellActiveState>1</CellActiveState><!--Active-->
                    //	<CellAdminState>0</CellAdminState><!--Unblock-->
                    //	<FddTddInd>0</FddTddInd><!--FDD-->
                    //	<CellSpecificOffset>15</CellSpecificOffset><!--0dB-->
                    //	<QoffsetFreq>15</QoffsetFreq><!--0dB-->
                    //	<RootSequenceIdx>185</RootSequenceIdx>
                    //	<HighSpeedFlag>0</HighSpeedFlag><!--Low speed cell flag-->
                    //	<PreambleFmt>0</PreambleFmt>
                    //	<CellRadius>7000</CellRadius>
                    //	<CustomizedBandWidthCfgInd>0</CustomizedBandWidthCfgInd><!--Not configure-->
                    //	<EmergencyAreaIdCfgInd>0</EmergencyAreaIdCfgInd><!--Not configure-->
                    //	<UePowerMaxCfgInd>0</UePowerMaxCfgInd><!--Not configure-->
                    //	<MultiRruCellFlag>0</MultiRruCellFlag><!--False-->
                    //	<CPRICompression>1</CPRICompression><!--Normal Compression-->
                    //	<AirCellFlag>0</AirCellFlag><!--False-->
                    //	<CrsPortNum>2</CrsPortNum><!--2 ports-->
                    //	<TxRxMode>3</TxRxMode><!--2T4R-->
                    //	<UserLabel></UserLabel>
                    //	<WorkMode>0</WorkMode><!--Uplink and downlink-->
                    //	<EuCellStandbyMode>0</EuCellStandbyMode><!--Active-->
                    //	<CellSlaveBand>
                    //		<element>
                    //		</element>
                    //	</CellSlaveBand>
                    //	<CnOpSharingGroupId>255</CnOpSharingGroupId>
                    //	<IntraFreqRanSharingInd>1</IntraFreqRanSharingInd><!--True-->
                    //	<IntraFreqAnrInd>1</IntraFreqAnrInd><!--ALLOWED-->
                    //	<CellScaleInd>0</CellScaleInd><!--MACRO-->
                    //	<FreqPriorityForAnr>0</FreqPriorityForAnr>
                    //	<CellRadiusStartLocation>0</CellRadiusStartLocation>
                    //	<objId>0</objId>
                    //</attributes>

                    var attributes = node.FirstChild;
                    var configurationModel = new CellConfigurationExtractForSecondQuery();
                    try
                    {
                        var xmlElement = attributes["LocalCellId"];
                        if (xmlElement != null)
                            configurationModel.LocalCellId = xmlElement.InnerText;
                        var element = attributes["CellName"];

                        if (element != null)
                            configurationModel.CellName = element.InnerText;
                    }
                    catch (Exception ex)
                    {
                    }
                    if (string.IsNullOrEmpty(configurationModel.CellName)) continue;

                    if (result.FirstOrDefault(p => p.CellName == configurationModel.CellName) == null)
                    {
                        result.Add(configurationModel);
                    }
                }

                #endregion
                
                #region get eUCellSectorEqm
                //From CellName, search in eNodeB config , for getting SectorEqmId
                //      <eUCellSectorEqm>
                //	        <attributes>
                //		        <LocalCellId>22</LocalCellId>
                //		        <SectorEqmId>4</SectorEqmId>
                //		        <ReferenceSignalPwr>32767</ReferenceSignalPwr>
                //		        <BaseBandEqmId>255</BaseBandEqmId>
                //		        <ReferenceSignalPwrMargin>0</ReferenceSignalPwrMargin>
                //		        <SectorCpriCompression>255</SectorCpriCompression><!--Invalid-->
                //	        </attributes>
                //      </eUCellSectorEqm>

                var eUCellSectorEqms = new List<EuCellSectorEqm>();
                XmlNodeList noteEuCellSectorEqm = xmlDoc.DocumentElement.GetElementsByTagName("eUCellSectorEqm");
                foreach (XmlNode euCellSectorEq in noteEuCellSectorEqm)
                {
                    var attributes = euCellSectorEq.FirstChild;
                    var eUCellSectorEqm = new EuCellSectorEqm();
                    try
                    {
                        eUCellSectorEqm.LocalCellId = attributes["LocalCellId"]?.InnerText ?? "";
                        eUCellSectorEqm.SectorEqmId = attributes["SectorEqmId"]?.InnerText ?? "";
                    }
                    catch (Exception)
                    {
                    }
                    if (string.IsNullOrEmpty(eUCellSectorEqm.LocalCellId))
                        continue;
                    //add if not exist
                    if (eUCellSectorEqms.FirstOrDefault(p => p.LocalCellId == eUCellSectorEqm.LocalCellId) == null)
                    {
                        eUCellSectorEqms.Add(eUCellSectorEqm);
                    }
                }


                //fill Configuration with SectorId
                foreach (var configuration in result)
                {
                    var findSector = eUCellSectorEqms.FirstOrDefault(p => p.LocalCellId == configuration.LocalCellId);
                    if (findSector != null)
                        configuration.SectorEqmId = findSector.SectorEqmId;
                }
                //get only configuration has SectorEqmId
                result = result.Where(p => !string.IsNullOrEmpty(p.SectorEqmId)).ToList();

                #endregion
                
                #region get SECTOREQM
                // From SectorEqmId , search in <SECTOREQM>

                var sectoreqms = new List<Sectoreqm>();
                XmlNodeList noteSectoreqm = xmlDoc.DocumentElement.GetElementsByTagName("SECTOREQM");
                foreach (XmlNode sectoreqm in noteSectoreqm)
                {
                    var attributes = sectoreqm.FirstChild;
                    var sectoreqmModel = new Sectoreqm();
                    try
                    {
                        sectoreqmModel.SectorEqmId = attributes["SECTOREQMID"]?.InnerText ?? "";
                        //sectoreqmModel.Sectorid = attributes["SECTORID"]?.InnerText ?? "";
                        var xmlElement = attributes["SECTOREQMANTENNA"];
                        if (xmlElement != null)
                        {
                            var elements = xmlElement.ChildNodes;

                            foreach (XmlNode element in elements)
                            {
                                //value of element
                                //<element>
                                // <CN>0</CN>
                                // <SRN>4</SRN>
                                // <SN>1</SN>
                                // <ANTN>0</ANTN><!--R0A-->
                                // <ANTTYPE>1</ANTTYPE><!--RX-->
                                // <TXBKPMODE>0</TXBKPMODE><!--Master-->
                                //</element>
                                var item = new Element
                                {
                                    Cn = element["CN"]?.InnerText ?? "",
                                    Srn = element["SRN"]?.InnerText ?? "",
                                    Sn = element["SN"]?.InnerText ?? "",
                                    Antn = element["ANTN"]?.InnerText ?? ""
                                };
                                sectoreqmModel.Elements.Add(item);
                                sectoreqms.Add(sectoreqmModel);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                    }
                }

                //filter configuration with SectorEqmId
                foreach (var configuration in result)
                {
                    var sectoreqmModel = sectoreqms.FirstOrDefault(p => p.SectorEqmId == configuration.SectorEqmId);
                    if (sectoreqmModel != null)
                    {
                        configuration.RxBranchAndAntennaPortValues =
                            sectoreqmModel.Elements.Select(p => new RxBranchAndAntennaPortValue()
                            {
                                Cn = p.Cn,
                                Antn = p.Antn,
                                Sn = p.Sn,
                                Srn = p.Srn
                            }).ToList();
                    }
                }

                #endregion

                #region get RXBRANCH

                var rxBranchs = new List<Rxbranch>();
                XmlNodeList rxBranchNodes = xmlDoc.DocumentElement.GetElementsByTagName("RXBRANCH");
                foreach (XmlNode rxBranchNode in rxBranchNodes)
                {
                    //<RXBRANCH>
                    // <attributes>
                    //  <CN>0</CN>
                    //  <SRN>4</SRN>
                    //  <SN>0</SN>
                    //  <RXNO>0</RXNO>
                    //  <RXSW>0</RXSW><!--ON-->
                    //  <ATTEN>22</ATTEN>
                    //  <RTWPINITADJ0>0</RTWPINITADJ0>
                    //  <RTWPINITADJ1>0</RTWPINITADJ1>
                    //  <RTWPINITADJ2>0</RTWPINITADJ2>
                    //  <RTWPINITADJ3>0</RTWPINITADJ3>
                    //  <RTWPINITADJ4>0</RTWPINITADJ4>
                    //  <RTWPINITADJ5>0</RTWPINITADJ5>
                    //  <RTWPINITADJ6>0</RTWPINITADJ6>
                    //  <RTWPINITADJ7>0</RTWPINITADJ7>
                    // </attributes>
                    //</RXBRANCH>

                    try
                    {
                        var attributes = rxBranchNode.FirstChild;
                        var rx = new Rxbranch
                        {
                            Cn = attributes["CN"]?.InnerText ?? "",
                            Srn = attributes["SRN"]?.InnerText ?? "",
                            Sn = attributes["SN"]?.InnerText ?? "",
                            RXNO = attributes["RXNO"]?.InnerText ?? "",
                            ATTEN = attributes["ATTEN"]?.InnerText ?? ""
                        };
                        rxBranchs.Add(rx);
                    }
                    catch (Exception ex)
                    {
                    }
                }

                //filter configuration with RXBRANCH
                foreach (var configuration in result)
                {
                    foreach (var element in configuration.RxBranchAndAntennaPortValues)
                    {
                        var rx =
                            rxBranchs.FirstOrDefault(
                                p =>
                                    p.Cn == element.Cn && p.Sn == element.Sn && p.Srn == element.Srn &&
                                    p.RXNO == element.Antn);
                        if (rx != null)
                        {
                            element.ATTEN = rx.ATTEN;
                        }
                    }
                }

                #endregion

                #region get ATTENNAPORT

                var AntennaPorts = new List<AntennaPort>();
                XmlNodeList AntennaPortNodes = xmlDoc.DocumentElement.GetElementsByTagName("ANTENNAPORT");
                foreach (XmlNode AntennaPortNode in AntennaPortNodes)
                {
                    //<ANTENNAPORT>
                    //	<attributes>
                    //		<CN>0</CN>
                    //		<SRN>4</SRN>
                    //		<SN>0</SN>
                    //		<PN>0</PN><!--R0A-->
                    //		<FEEDERLENGTH>0</FEEDERLENGTH>
                    //		<DLDELAY>100</DLDELAY>
                    //		<ULDELAY>100</ULDELAY>
                    //		<PWRSWITCH>1</PWRSWITCH><!--OFF-->
                    //		<THRESHOLDTYPE>5</THRESHOLDTYPE><!--TMA12DB_AISG-->
                    //		<UOTHD>30</UOTHD>
                    //		<UCTHD>40</UCTHD>
                    //		<OOTHD>450</OOTHD>
                    //		<OCTHD>400</OCTHD>
                    //		<ULTRADELAYSW>0</ULTRADELAYSW><!--OFF-->
                    //	</attributes>
                    //</ANTENNAPORT>

                    try
                    {
                        var attributes = AntennaPortNode.FirstChild;
                        var ap = new AntennaPort()
                        {
                            Cn = attributes["CN"]?.InnerText ?? "",
                            Srn = attributes["SRN"]?.InnerText ?? "",
                            Sn = attributes["SN"]?.InnerText ?? "",
                            Pn = attributes["PN"]?.InnerText ?? "",
                            Pwrswitch = attributes["PWRSWITCH"]?.InnerText ?? ""
                        };
                        AntennaPorts.Add(ap);
                    }
                    catch (Exception ex)
                    {
                    }
                }

                //filter configuration with RXBRANCH
                foreach (var configuration in result)
                {
                    foreach (var element in configuration.RxBranchAndAntennaPortValues)
                    {
                        var ap =
                            AntennaPorts.FirstOrDefault(
                                p =>
                                    p.Cn == element.Cn && p.Sn == element.Sn && p.Srn == element.Srn &&
                                    p.Pn == element.Antn);
                        if (ap != null)
                        {
                            element.POWERSWITCH = ap.Pwrswitch;
                            element.CombineValue = string.Format("CN={0},SRN={1},SN={2},PN={3}", ap.Cn, ap.Srn, ap.Sn, ap.Pn);
                        }
                    }
                }

                #endregion

                //clear element 
            }
            return result;
        }

        public void ExportConfigurationForSecondQueryAndUploadToBlob(DateTime today)
        {
            var guid = Guid.NewGuid().ToString();
            var fileNamePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, guid + "-secondconfiguration.csv");

            string constr = ConfigurationManager.ConnectionStrings["AmsContext"].ConnectionString;

            SqlConnection spContentConn = new SqlConnection(constr);
            SqlCommand sqlcmd = new SqlCommand();
            StreamWriter CsvfileWriter = new StreamWriter(fileNamePath);
            sqlcmd.Connection = spContentConn;
            sqlcmd.CommandTimeout = 0;
            sqlcmd.CommandType = CommandType.Text;
            string sqlselectQuery = "SELECT CellName,AdditionInfoForAtten,AdditionInfoForPwr,AllAttenDifferent,AllAttenSame,AllPwrDifferent,AllPwrSame FROM CellConfigurationSecondQuery Where CreatedDateUtc = '" + today.ToString("yyyy-MM-dd HH:mm:ss.FFF")+"'";
            sqlcmd.CommandText = sqlselectQuery;
            spContentConn.Open();
            using (spContentConn)
            {
                using (SqlDataReader sdr = sqlcmd.ExecuteReader())
                using (CsvfileWriter) 
                {
                    //This Block of code for getting the Table Headers
                    DataTable Tablecolumns = new DataTable();

                    for (int i = 0; i < sdr.FieldCount; i++)
                    {
                        Tablecolumns.Columns.Add(sdr.GetName(i));
                    }
                    Tablecolumns.Columns.Add("CreatedDateUtc");
                    CsvfileWriter.WriteLine(string.Join(",", Tablecolumns.Columns.Cast<DataColumn>().Select(csvfile => csvfile.ColumnName)));
                    while (sdr.Read())
                    {
                        CsvfileWriter.WriteLine(sdr[0].ToString() + "," + "\"" + sdr[1].ToString() + "\"" + ","
                            + "\"" + sdr[2].ToString() + "\"" + "," + sdr[3].ToString()
                       + "," + sdr[4].ToString() + "," + sdr[5].ToString() + "," + sdr[6].ToString() + "," + today.ToString("yyyy-MM-dd'T'HH:mm:ss.FFF'Z'") + ",");
                    }
                }
            }
            spContentConn.Close();
            // Retrieve reference to a blob
            var blobContainer = AzureHelper.AlarmCloudBlobContainer;
            var blobName = "secondconfiguration.csv";
            var blob = blobContainer.GetBlockBlobReference(blobName);

            // Set the blob content type
            blob.Properties.ContentType = "text/csv";

            // Upload file into blob storage, basically copying it from local disk into Azure
            using (var fs2 = File.OpenRead(fileNamePath))
            {
                blob.UploadFromStream(fs2);
            }
        }
    }



    #region model for 2nd query
    public class CellConfigurationExtractForSecondQuery
    {
        /// <summary>
        /// LocalCellId
        /// </summary>
        public string LocalCellId { get; set; }

        /// <summary>
        /// CellName
        /// </summary>
        public string CellName { get; set; }

        public string SectorEqmId { get; set; }

        public List<RxBranchAndAntennaPortValue> RxBranchAndAntennaPortValues { get; set; }

        public CellConfigurationExtractForSecondQuery()
        {
            RxBranchAndAntennaPortValues = new List<RxBranchAndAntennaPortValue>();
        }
    }

    public class RxBranchAndAntennaPortValue
    {
        public string Cn { get; set; }
        public string Srn { get; set; }
        public string Sn { get; set; }
        public string Antn { get; set; }
        public string CombineValue { get; set; }
        public string ATTEN { get; set; }
        /// <summary>
        /// 1=OFF , 0 = ON
        /// </summary>
        public string POWERSWITCH { get; set; }
    }

    public class RxbranchValue
    {
        public string CombineValue { get; set; }
        public string ATTEN { get; set; }
    }

    public class AntennaPortValue
    {
        public string CombineValue { get; set; }
        /// <summary>
        /// 1=OFF , 0 = ON
        /// </summary>
        public string POWERSWITCH { get; set; }
    }
    public class EuCellSectorEqm
    {
        public string LocalCellId { get; set; }

        public string SectorEqmId { get; set; }
    }

    public class Sectoreqm
    {
        public string SectorEqmId { get; set; }
        //public string Sectorid { get; set; }

        public List<Element> Elements { get; set; }

        public Sectoreqm()
        {
            Elements = new List<Element>();
        }


    }
    //Combine of 4 value CN SRN SN ANTN
    public class Element
    {
        public string Cn { get; set; }
        public string Srn { get; set; }
        public string Sn { get; set; }
        public string Antn { get; set; }
    }

    public class Rxbranch
    {
        public string Cn { get; set; }
        public string Srn { get; set; }
        public string Sn { get; set; }
        public string RXNO { get; set; }

        public string ATTEN { get; set; }
    }

    public class AntennaPort
    {
        public string Cn { get; set; }
        public string Srn { get; set; }
        public string Sn { get; set; }
        public string Pn { get; set; }
        public string Pwrswitch { get; set; }
    }
    #endregion
}

﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.ServiceBus.Messaging;
using Newtonsoft.Json;
using OfficeOpenXml;

namespace StreamAnalyticService
{
    /// <summary>
    /// Implement cell data process 
    /// </summary>
    public class CellDataProcessService:ICellDataProcessService
    {
        private static readonly string CellDataSenderHub = ConfigurationManager.AppSettings["cellDataSender.Path"];
        private static readonly string CellDatasenderConnectionString = ConfigurationManager.AppSettings["cellDataSender.ConnectionString"];
        private static readonly string CellDataSenderHubTest = ConfigurationManager.AppSettings["cellDataSenderTest.Path"];
        private static readonly string CellDatasenderConnectionStringTest = ConfigurationManager.AppSettings["cellDataSenderTest.ConnectionString"];
        public List<CellDataExtract> ExtractData(string folderPath, string dateTime)
        {
            var result = new List<CellDataExtract>();
            var fileNameSuffix = string.Format("{0}.xlsx", dateTime);
            var fileNameFinds = GetFilesNameEndWithDateTime(folderPath, fileNameSuffix);
            foreach (var fileName in fileNameFinds)
            {
                if (File.Exists(fileName))
                {
                    
                    using (var stream = new FileStream(fileName, FileMode.Open))
                    {
                        var data = ExtractAllKpiFromExcelStream(stream);
                        result.AddRange(data);
                    }
                }
            }
            return result;
        }

        public List<CellDataExtract> ExtractData(Stream stream)
        {
            var result = new List<CellDataExtract>();

            try
            {

                using (var pck = new ExcelPackage(stream))
                {
                    var workSheet = pck.Workbook.Worksheets.First();

                    int numRows = workSheet.Dimension.End.Row;
                    int numCols = workSheet.Dimension.End.Column;

                    if (numRows < 2 || numCols < 4) return result;

                    int indexCreatedDate = 0;
                    int indexCellId = 0;
                    int indexRank1 = 0;
                    int indexRank2 = 0;
                    int indexRank3 = 0;
                    int indexRank4 = 0;
                    int indexFourGenDetect = 0;

                    string fourGenDetect = "L.UL.Interference.Avg (dBm)";

                    for (var i = 1; i <= numCols; i++)
                    {
                        var columnHeader = workSheet.Cells[1, i].Text;
                        if (!string.IsNullOrEmpty(columnHeader))
                        {
                            if (columnHeader.Equals("Start Time", StringComparison.Ordinal))
                                indexCreatedDate = i;
                            else if (columnHeader.Equals("Cell", StringComparison.Ordinal))
                                indexCellId = i;
                            else if (columnHeader.Equals("L.ChMeas.MIMO.PRB.OL.Rank1 (None)", StringComparison.Ordinal))
                                indexRank1 = i;
                            else if (columnHeader.Equals("L.ChMeas.MIMO.PRB.OL.Rank2 (None)", StringComparison.Ordinal))
                                indexRank2 = i;
                            else if (columnHeader.Equals("L.ChMeas.MIMO.PRB.OL.Rank3 (None)", StringComparison.Ordinal))
                                indexRank3 = i;
                            else if (columnHeader.Equals("L.ChMeas.MIMO.PRB.OL.Rank4 (None)", StringComparison.Ordinal))
                                indexRank4 = i;
                            else if (columnHeader.Equals(fourGenDetect, StringComparison.Ordinal))
                                indexFourGenDetect = i;
                        }
                    }
                    if (indexCreatedDate < 1 || indexCellId < 1 || indexRank1 < 1 || indexRank2 < 1 || indexRank3 < 1 || indexRank4 < 1)
                        return result;
                    for (var i = 2; i <= numRows; i++)
                    {
                        DateTime createdDateUtc;
                        decimal rank1, rank2, rank3, rank4;

                        var cellEnodeBInfo = workSheet.Cells[i, indexCellId].Text;
                        if (string.IsNullOrEmpty(cellEnodeBInfo)
                            || !DateTime.TryParse(workSheet.Cells[i, indexCreatedDate].Value.ToString(), out createdDateUtc)
                            || !decimal.TryParse(workSheet.Cells[i, indexRank1].Value.ToString(), out rank1)
                            || !decimal.TryParse(workSheet.Cells[i, indexRank2].Value.ToString(), out rank2)
                            || !decimal.TryParse(workSheet.Cells[i, indexRank3].Value.ToString(), out rank3)
                            || !decimal.TryParse(workSheet.Cells[i, indexRank4].Value.ToString(), out rank4))
                            continue;
                        var cellName = GetCellInfo(cellEnodeBInfo, "Cell Name");
                        var cellId = GetCellInfo(cellEnodeBInfo, "Local Cell ID");
                        var enodeBId = GetCellInfo(cellEnodeBInfo, "eNodeB ID");
                        var cellKpi = new CellDataExtract()
                        {
                            InDateUtc = createdDateUtc,
                            CellName = cellName,
                            CellId = cellId,
                            Rank1 = rank1,
                            Rank2 = rank2,
                            Rank3 = rank3,
                            Rank4 = rank4,
                            EnodeBId = enodeBId

                        };
                        //this kpi is for 4g cell
                        if (indexFourGenDetect > 0)
                        {
                            cellKpi.CellType = (int)CellTypeExtract.FourthGen;
                            decimal avgDb = 0;
                            decimal.TryParse(workSheet.Cells[i, indexFourGenDetect].Value.ToString(), out avgDb);
                            cellKpi.InterferenceAvg = avgDb;
                        }
                        result.Add(cellKpi);
                     //   return cellKpi;
                    }
                }
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<CellDataExtract> ExtractDataForTesting(Stream stream,string testId)
        {
            var result = new List<CellDataExtract>();

            try
            {

                using (var pck = new ExcelPackage(stream))
                {
                    var workSheet = pck.Workbook.Worksheets.First();

                    int numRows = workSheet.Dimension.End.Row;
                    int numCols = workSheet.Dimension.End.Column;

                    if (numRows < 2 || numCols < 4) return result;

                    int indexCreatedDate = 0;
                    int indexCellId = 0;
                    int indexRank1 = 0;
                    int indexRank2 = 0;
                    int indexRank3 = 0;
                    int indexRank4 = 0;
                    int indexFourGenDetect = 0;

                    string fourGenDetect = "L.UL.Interference.Avg (dBm)";

                    for (var i = 1; i <= numCols; i++)
                    {
                        var columnHeader = workSheet.Cells[1, i].Text;
                        if (!string.IsNullOrEmpty(columnHeader))
                        {
                            if (columnHeader.Equals("Start Time", StringComparison.Ordinal))
                                indexCreatedDate = i;
                            else if (columnHeader.Equals("Cell", StringComparison.Ordinal))
                                indexCellId = i;
                            else if (columnHeader.Equals("L.ChMeas.MIMO.PRB.OL.Rank1 (None)", StringComparison.Ordinal))
                                indexRank1 = i;
                            else if (columnHeader.Equals("L.ChMeas.MIMO.PRB.OL.Rank2 (None)", StringComparison.Ordinal))
                                indexRank2 = i;
                            else if (columnHeader.Equals("L.ChMeas.MIMO.PRB.OL.Rank3 (None)", StringComparison.Ordinal))
                                indexRank3 = i;
                            else if (columnHeader.Equals("L.ChMeas.MIMO.PRB.OL.Rank4 (None)", StringComparison.Ordinal))
                                indexRank4 = i;
                            else if (columnHeader.Equals(fourGenDetect, StringComparison.Ordinal))
                                indexFourGenDetect = i;
                        }
                    }
                    if (indexCreatedDate < 1 || indexCellId < 1 || indexRank1 < 1 || indexRank2 < 1 || indexRank3 < 1 || indexRank4 < 1)
                        return result;
                    for (var i = 2; i <= numRows; i++)
                    {
                        DateTime createdDateUtc;
                        decimal rank1, rank2, rank3, rank4;

                        var cellEnodeBInfo = workSheet.Cells[i, indexCellId].Text;
                        if (string.IsNullOrEmpty(cellEnodeBInfo)
                            || !DateTime.TryParse(workSheet.Cells[i, indexCreatedDate].Value.ToString(), out createdDateUtc)
                            || !decimal.TryParse(workSheet.Cells[i, indexRank1].Value.ToString(), out rank1)
                            || !decimal.TryParse(workSheet.Cells[i, indexRank2].Value.ToString(), out rank2)
                            || !decimal.TryParse(workSheet.Cells[i, indexRank3].Value.ToString(), out rank3)
                            || !decimal.TryParse(workSheet.Cells[i, indexRank4].Value.ToString(), out rank4))
                            continue;
                      

                        var cellName = GetCellInfo(cellEnodeBInfo, "Cell Name");
                        var cellId = GetCellInfo(cellEnodeBInfo, "Local Cell ID");
                        var enodeBId = GetCellInfo(cellEnodeBInfo, "eNodeB ID");
                        
                        var cellKpi = new CellDataExtract()
                        {
                            TestId = testId,
                            InDateUtc = createdDateUtc,
                            CellName = cellName,
                            //CellId = cellId + testId,
                            CellId = cellId ,
                            Rank1 = rank1,
                            Rank2 = rank2,
                            Rank3 = rank3,
                            Rank4 = rank4,
                            EnodeBId = enodeBId ,

                        };
                        //this kpi is for 4g cell
                        if (indexFourGenDetect > 0)
                        {
                            cellKpi.CellType = (int)CellTypeExtract.FourthGen;
                            decimal avgDb = 0;
                            decimal.TryParse(workSheet.Cells[i, indexFourGenDetect].Value.ToString(), out avgDb);
                            cellKpi.InterferenceAvg = avgDb;
                        }
                        result.Add(cellKpi);
                        //   return cellKpi;
                    }
                }
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task SendCellDataToStream(List<CellDataExtract> data)
        {
            var partitionKey = Guid.NewGuid().ToString();
            if (data == null) return;
            if (data.Count == 0) return;
            var eventHubClient = EventHubClient.CreateFromConnectionString(CellDatasenderConnectionString, CellDataSenderHub);
            var listEventData = data.Select(p => 
            new EventData(Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(p))
            )
            {
                PartitionKey = partitionKey
            }
            );
            try
            {
                await eventHubClient.SendBatchAsync(listEventData);
            }
            catch (Exception ex)
            {
                throw ex;
            }


        }
        public async Task SendCellDataToStreamTest(List<CellDataExtract> data)
        {
            if (data == null) return;
            if (data.Count == 0) return;
            var eventHubClient = EventHubClient.CreateFromConnectionString(CellDatasenderConnectionStringTest, CellDataSenderHubTest);
            var listEventData = data.Select(p => new EventData(Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(p))));
            try
            {
                await eventHubClient.SendBatchAsync(listEventData);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }



        public Task SendCellDataToStream(CellDataExtract data)
        {
            return SendCellDataToStreamTest(new List<CellDataExtract> {data});
        }



        #region utils

        private List<string> GetFilesNameEndWithDateTime(string folderPath, string suffixName)
        {
            try
            {
                var files = Directory.GetFiles(folderPath);
                var result = files.Where(x => x.EndsWith(suffixName, StringComparison.OrdinalIgnoreCase)).ToList();
                return result;
            }
            catch (Exception ex)
            {
              
                throw;
            }
        }

        private List<CellDataExtract> ExtractAllKpiFromExcelStream(FileStream stream)
        {
            try
            {
                var result = new List<CellDataExtract>();

                using (var pck = new ExcelPackage(stream))
                {
                    var workSheet = pck.Workbook.Worksheets.First();

                    int numRows = workSheet.Dimension.End.Row;
                    int numCols = workSheet.Dimension.End.Column;

                    if (numRows < 2 || numCols < 4) return result;

                    int indexCreatedDate = 0;
                    int indexCellId = 0;
                    int indexRank1 = 0;
                    int indexRank2 = 0;
                    int indexRank3 = 0;
                    int indexRank4 = 0;
                    int indexFourGenDetect = 0;
                    
                    string fourGenDetect = "L.UL.Interference.Avg (dBm)";

                    for (var i = 1; i <= numCols; i++)
                    {
                        var columnHeader = workSheet.Cells[1, i].Text;
                        if (!string.IsNullOrEmpty(columnHeader))
                        {
                            if (columnHeader.Equals("Start Time", StringComparison.Ordinal))
                                indexCreatedDate = i;
                            else if (columnHeader.Equals("Cell", StringComparison.Ordinal))
                                indexCellId = i;
                            else if (columnHeader.Equals("L.ChMeas.MIMO.PRB.OL.Rank1 (None)", StringComparison.Ordinal))
                                indexRank1 = i;
                            else if (columnHeader.Equals("L.ChMeas.MIMO.PRB.OL.Rank2 (None)", StringComparison.Ordinal))
                                indexRank2 = i;
                            else if (columnHeader.Equals("L.ChMeas.MIMO.PRB.OL.Rank3 (None)", StringComparison.Ordinal))
                                indexRank3 = i;
                            else if (columnHeader.Equals("L.ChMeas.MIMO.PRB.OL.Rank4 (None)", StringComparison.Ordinal))
                                indexRank4 = i;
                            else if (columnHeader.Equals(fourGenDetect, StringComparison.Ordinal))
                                indexFourGenDetect = i;
                        }
                    }
                    if (indexCreatedDate < 1 || indexCellId < 1 || indexRank1 < 1 || indexRank2 < 1 || indexRank3 < 1 || indexRank4 < 1)
                        return result;
                    for (var i = 2; i <= numRows; i++)
                    {
                        DateTime createdDateUtc;
                        decimal rank1, rank2,rank3,rank4;

                        var cellEnodeBInfo = workSheet.Cells[i, indexCellId].Text;
                        if (string.IsNullOrEmpty(cellEnodeBInfo)
                            || !DateTime.TryParse(workSheet.Cells[i, indexCreatedDate].Value.ToString(), out createdDateUtc)
                            || !decimal.TryParse(workSheet.Cells[i, indexRank1].Value.ToString(), out rank1)
                            || !decimal.TryParse(workSheet.Cells[i, indexRank2].Value.ToString(), out rank2)
                            || !decimal.TryParse(workSheet.Cells[i, indexRank3].Value.ToString(), out rank3)
                            || !decimal.TryParse(workSheet.Cells[i, indexRank4].Value.ToString(), out rank4))
                            continue;
                        var cellName = GetCellInfo(cellEnodeBInfo, "Cell Name");
                        var cellId = GetCellInfo(cellEnodeBInfo, "Local Cell ID");
                        var enodeBId = GetCellInfo(cellEnodeBInfo, "eNodeB ID");
                        var cellKpi = new CellDataExtract()
                        {
                            InDateUtc = createdDateUtc,
                            CellName = cellName,
                            CellId = cellId,
                            Rank1 = rank1,
                            Rank2 = rank2,
                            Rank3 = rank3,
                            Rank4 = rank4,
                            EnodeBId = enodeBId

                        };
                        //this kpi is for 4g cell
                        if (indexFourGenDetect > 0)
                        {
                            cellKpi.CellType =(int) CellTypeExtract.FourthGen;
                            decimal avgDb = 0;
                            decimal.TryParse(workSheet.Cells[i, indexFourGenDetect].Value.ToString(), out avgDb);
                            cellKpi.InterferenceAvg = avgDb;
                        }

                        result.Add(cellKpi);
                    }
                }
                return result;
            }
            catch (Exception ex)
            {
               throw ex;
            }
        }
        private string GetCellInfo(string dataStr,string fieldName)
        {
            var data = dataStr.Split(',');
            var firstOrDefault = data.FirstOrDefault(x => x.Contains(fieldName));
            if (firstOrDefault != null)
            {
                var res = firstOrDefault.Split('=')[1];
                return res;
            }
            return "";
        }

        #endregion
    }
}

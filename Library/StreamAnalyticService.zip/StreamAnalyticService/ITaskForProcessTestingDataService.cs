﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StreamAnalyticService
{ 
    /// <summary>
    /// Service for processing in background task, calculate data for testing 
    /// </summary>
    public interface ITaskForProcessTestingDataService
    {

        /// <summary>
        /// Function run each 5 minute for calculate what is testing for SA requests
        /// </summary>
        void ProcessDataPer5Minute();
        /// <summary>
        /// Function run testing for SA requests
        /// </summary>
        void ProcessDataForTestingRequest(string testId);
    }
}

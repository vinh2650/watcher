﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.ServiceBus.Messaging;
using Newtonsoft.Json;
using StreamAnalyticService.SaAlarmRequest;
using StreamAnalyticService.SaResult;

namespace StreamAnalyticService.SaProcessService
{
    public class SaService:ISaService
    {
        private static readonly string SenderAlarmConnectionString = ConfigurationManager.AppSettings["SenderAlarm.ConnectionString"];
        private static readonly string SenderAlarmPath = ConfigurationManager.AppSettings["SenderAlarm.Path"];
        
        private EventHubClient senderAlarmHubClient = EventHubClient.CreateFromConnectionString(SenderAlarmConnectionString, SenderAlarmPath);


        public void RemoveAlarmForData(ReturnCell cell)
        {
            Trace.WriteLine("remove alarm for: " + cell.CellName);

        }

        public void AddAlarmForData(ReturnCell cell)
        {
            Trace.WriteLine("add alarm for: " + cell.CellName);
        }

        public void SendNullAlarmToStream(ReturnCell cell)
        {
            Trace.WriteLine("send null alarm for: " + cell.CellName);
            ////send another alarm event
            //var saCell = new SaAlarmEvent
            //{
            //    CellId = cell.CellName,
            //    Alarm = "",
            //    CreateDateTimeUtc = DateTime.UtcNow
            //};
          
            //senderAlarmHubClient.Send(
            //    new EventData(
            //        Encoding.UTF8.GetBytes(
            //            JsonConvert.SerializeObject(saCell)
            //            )));
            //Trace.WriteLine(DateTime.Now.ToString() + " remove Alarm for: " + cell.CellName);

        }

        public void SendMimoAlarmToStream(ReturnCell cell)
        {
            Trace.WriteLine("send MIMO alarm for: " + cell.CellName);
            //send another alarm event
            //var saCell = new SaAlarmEvent
            //{
            //    CellId = cell.CellId,
            //    Alarm = "MIMO degradation",
            //    CreateDateTimeUtc = DateTime.UtcNow
            //};

            //senderAlarmHubClient.Send(
            //    new EventData(
            //        Encoding.UTF8.GetBytes(
            //            JsonConvert.SerializeObject(saCell)
            //            )));
            //Trace.WriteLine(DateTime.Now.ToString() + " send MIMO Alarm for: " + cell.CellId);

        }
    }
}

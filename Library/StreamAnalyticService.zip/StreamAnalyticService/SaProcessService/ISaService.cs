﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StreamAnalyticService.SaResult;

namespace StreamAnalyticService.SaProcessService
{
    /// <summary>
    /// Service for handling message from SA 
    /// </summary>
    public interface ISaService
    {
        /// <summary>
        /// remove alarm for cell
        /// </summary>
        /// <param name="cell"></param>
        void RemoveAlarmForData(ReturnCell cell);
        /// <summary>
        /// add alarm for cell
        /// </summary>
        /// <param name="cell"></param>
        void AddAlarmForData(ReturnCell cell);
        /// <summary>
        /// Send null alarm to stream
        /// </summary>
        /// <param name="cell"></param>
        void SendNullAlarmToStream(ReturnCell cell);
        /// <summary>
        /// Send  alarm to stream
        /// </summary>
        /// <param name="cell"></param>
        void SendMimoAlarmToStream(ReturnCell cell);
    }
}

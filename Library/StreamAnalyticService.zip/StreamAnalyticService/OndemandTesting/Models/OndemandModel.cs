﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Core.Domain.Business.StreamAnalyticEntity;

namespace StreamAnalyticService.OndemandTesting.Models
{
    /// <summary>
    /// 
    /// </summary>
    public class TestPerformanceData
    {

        public string TestId { get; set; }

        /// <summary>
        /// Cell Id
        /// </summary>
        public string CellId { get; set; }


        /// <summary>
        /// Cell Name
        /// </summary>
        public string CellName { get; set; }

        /// <summary>
        /// InDateUtc, mapping with column StartTime in excel file
        /// </summary>
        public DateTime InDateUtc { get; set; }
        /// <summary>
        /// InDateUtc, mapping with column StartTime in excel file
        /// </summary>
        public DateTime DateWithoutTimeUtc { get; set; }
        /// <summary>
        /// Mapping with column L.ChMeas.MIMO.PRB.CL.Rank1 (None) or column D in excel file
        /// </summary>
        public decimal Rank1 { get; set; }

        /// <summary>
        /// Mapping with column L.ChMeas.MIMO.PRB.CL.Rank2 (None) or column E in excel file
        /// </summary>
        public decimal Rank2 { get; set; }

        /// <summary>
        /// Mapping with column L.ChMeas.MIMO.PRB.CL.Rank1 (None) or column D in excel file
        /// </summary>
        public decimal Rank3 { get; set; }

        /// <summary>
        /// Mapping with column L.ChMeas.MIMO.PRB.CL.Rank2 (None) or column E in excel file
        /// </summary>
        public decimal Rank4 { get; set; }

        /// <summary>
        /// Interference avg, for 4g
        /// </summary>
        public decimal InterferenceAvg { get; set; }

        /// <summary>
        /// rtwp for 3g
        /// </summary>
        public decimal Rtwp { get; set; }

        public int CellType { get; set; }

        public string EnodeBId { get; set; }

        public int SecondWillBeAdd { get; set; }

        public string NeName { get; set; }

    }
    /// <summary>
    /// 
    /// </summary>
    public class TestNetworkAlarm
    {

    }
    /// <summary>
    /// 
    /// </summary>
    public class TestConfigurationReferenceOne
    {

        public string SectorEqmId { get; set; }
        /// <summary>
        /// LocalCellId
        /// </summary>
        public string LocalCellId { get; set; }

        /// <summary>
        /// CellName
        /// </summary>
        public string CellName { get; set; }


        /// <summary>
        /// <TxRxMode>0</TxRxMode><!--1T1R-->
        /// </summary>
        public string TxRxMode { get; set; }

        public string AdditionInfoForAtten { get; set; }
        public string AdditionInfoForPwr { get; set; }


        public bool AllAttenDifferent { get; set; }
        public bool AllAttenSame { get; set; }

        public bool AllPwrDifferent { get; set; }
        public bool AllPwrSame { get; set; }


        public DateTime CreatedDateUtc { get; set; }

        public List<TestConfigurationForPwrSwitchAndAtten> PwrSwitchAndAttens { get; set; }
        public List<RxBranchAndAntennaPortValue> RxBranchAndAntennaPortValues { get; set; }
        public TestConfigurationReferenceOne()
        {
            PwrSwitchAndAttens = new List<TestConfigurationForPwrSwitchAndAtten>();
            RxBranchAndAntennaPortValues = new List<RxBranchAndAntennaPortValue>();
        }
    }

    public class RxBranchAndAntennaPortValue
    {
        public string Cn { get; set; }
        public string Srn { get; set; }
        public string Sn { get; set; }
        public string Antn { get; set; }
        public string CombineValue { get; set; }
        public string ATTEN { get; set; }
        /// <summary>
        /// 1=OFF , 0 = ON
        /// </summary>
        public string POWERSWITCH { get; set; }
    }

    ///// <summary>
    ///// 
    ///// </summary>
    //public class TestConfigurationReferenceTwo
    //{
    //    public string CellName { get; set; }


    //    public string AdditionInfoForAtten { get; set; }

    //    public string AdditionInfoForPwr { get; set; }

    //    public bool AllAttenDifferent { get; set; }

    //    public bool AllAttenSame { get; set; }

    //    public bool AllPwrDifferent { get; set; }

    //    public bool AllPwrSame { get; set; }
    //}

    public class TestConfigurationForPwrSwitchAndAtten
    {

        public DateTime CreateDateUtc { get; set; }

        public string CellName { get; set; }

        /// <summary>
        /// in format CN/SRN/SN/RN
        /// </summary>
        public string CnSrnSnRn { get; set; }

        public string PWRSWITCH { get; set; }

        public string ATTEN { get; set; }

    }


    #region result

    public class TestOutputEvent
    {
        public string TestId { get; set; }


        public CellType CellType { get; set; }

        /// <summary>
        /// Local cell id
        /// </summary>
        public string LocalCellId { get; set; }
        /// <summary>
        /// Cell Name
        /// </summary>
        public string CellName { get; set; }
        /// <summary>
        /// Slogan
        /// </summary>
        public string Slogan { get; set; }


        /// <summary>
        /// Severity
        /// </summary>
        public string Severity { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string MoClass { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string MoInstance { get; set; }

        public string AdditionInfo { get; set; }

        public string ENodeBId { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public double AverageRank { get; set; }


        public string ExecuteCode { get; set; }

        public TestExecuteCode TestExecuteCode { get; set; }


        public string Note { get; set; }
    }
    
    #endregion

}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StreamAnalyticService
{
    /// <summary>
    /// Cell data extract from excel
    /// </summary>
    public class CellDataExtract
    {

        public string TestId { get; set; }

        /// <summary>
        /// Cell Id
        /// </summary>
        public string CellId { get; set; }


        /// <summary>
        /// Cell Name
        /// </summary>
        public string CellName { get; set; }

        /// <summary>
        /// InDateUtc, mapping with column StartTime in excel file
        /// </summary>
        public DateTime InDateUtc { get; set; }

        /// <summary>
        /// Mapping with column L.ChMeas.MIMO.PRB.CL.Rank1 (None) or column D in excel file
        /// </summary>
        public decimal Rank1 { get; set; }

        /// <summary>
        /// Mapping with column L.ChMeas.MIMO.PRB.CL.Rank2 (None) or column E in excel file
        /// </summary>
        public decimal Rank2 { get; set; }

        /// <summary>
        /// Mapping with column L.ChMeas.MIMO.PRB.CL.Rank1 (None) or column D in excel file
        /// </summary>
        public decimal Rank3 { get; set; }

        /// <summary>
        /// Mapping with column L.ChMeas.MIMO.PRB.CL.Rank2 (None) or column E in excel file
        /// </summary>
        public decimal Rank4 { get; set; }

        /// <summary>
        /// Interference avg, for 4g
        /// </summary>
        public decimal InterferenceAvg { get; set; }
        /// <summary>
        /// rtwp for 3g
        /// </summary>
        public decimal Rtwp { get; set; }

        public int CellType { get; set; }

        public string EnodeBId { get; set; }

        public int SecondWillBeAdd { get; set; }
    }
    public enum CellTypeExtract
    {
        /// <summary>
        /// 2G
        /// </summary>
        TwoGen = 2,

        /// <summary>
        /// 3G
        /// </summary>
        ThereGen = 3,
        /// <summary>
        /// 4G
        /// </summary>
        FourthGen = 4
    }
}

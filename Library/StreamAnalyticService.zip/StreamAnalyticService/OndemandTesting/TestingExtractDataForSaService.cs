﻿
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using Common.Helper;
using Core.Domain.Business.StreamAnalyticEntity;
using Microsoft.ServiceBus;
using Microsoft.ServiceBus.Messaging;
using Newtonsoft.Json;
using OfficeOpenXml;
using Service.CachingLayer;
using StreamAnalyticService.OndemandTesting.Models;

namespace StreamAnalyticService.OndemandTesting
{
    public class TestingExtractDataForSaService : ITestingExtractDataForSaService
    {

        private readonly DbContext _dbContext;
        private readonly DbSet<TestingLogEvent> _testingLogEvents;
        private readonly DbSet<TestingSaRequest> _testingSaRequestDbSet;
        private readonly DbSet<TestAlarmRecord> _testAlarmRecordDbSet;
        private readonly DbSet<TestHistoryAlarmRecord> _testHistoryAlarmRecordDbSet;
        private readonly DbSet<TestingConfiguration> _testConfigurationDbSet;

        private const string KeyForCacheTestingRecordById = "AMS_TestingRequest_By_Id_{0}";
        private const string KeyForCacheTestAlarmByCellNameAndSloganAndTestId = "AMS_TestingAlarm_By_CellName_And_Slogan_{0}_{1}_{2}";
        private const string KeyForCacheTestingConfigurationByCellNameAndDateAndTestId = "AMS_TestingConfiguration_By_CellName_And_Date_{0}_{1}_{2}";
        private static string eventHubName = "testingamsnetworkalarm";
        private static string connectionString =
            "Endpoint=sb://amsiotsystem.servicebus.windows.net/;SharedAccessKeyName=amstesting;SharedAccessKey=FTM1gesuHRype5fYi3eEM0OMSVo42di2m+MveUE+e2g=";

        
        private readonly ICacheManager _cacheManager;
        public TestingExtractDataForSaService(DbContext dbContext, ICacheManager cacheManager)
        {
            _dbContext = dbContext;
            _cacheManager = cacheManager;
            _testingLogEvents = dbContext.Set<TestingLogEvent>();
            _testingSaRequestDbSet = dbContext.Set<TestingSaRequest>();
            _testAlarmRecordDbSet = dbContext.Set<TestAlarmRecord>();
            _testConfigurationDbSet = dbContext.Set<TestingConfiguration>();
            _testHistoryAlarmRecordDbSet = dbContext.Set<TestHistoryAlarmRecord>();
          
        }

        public List<TestPerformanceData> ExtractKpiForTesting(Stream stream, string testId)
        {
            var result = new List<TestPerformanceData>();

            try
            {

                using (var pck = new ExcelPackage(stream))
                {
                    var workSheet = pck.Workbook.Worksheets.First();

                    int numRows = workSheet.Dimension.End.Row;
                    int numCols = workSheet.Dimension.End.Column;
                    if (numRows < 2 || numCols < 4) return result;
                    int indexCreatedDate = 0;
                    int indexCellId = 0;
                    int indexRank1 = 0;
                    int indexRank2 = 0;
                    int indexRank3 = 0;
                    int indexRank4 = 0;
                    int indexFourGenDetect = 0;
                    int indexNeName = 0;
                    string fourGenDetect = "L.UL.Interference.Avg (dBm)";

                    for (var i = 1; i <= numCols; i++)
                    {
                        var columnHeader = workSheet.Cells[1, i].Text;
                        if (!string.IsNullOrEmpty(columnHeader))
                        {
                            if (columnHeader.Equals("Start Time", StringComparison.Ordinal))
                                indexCreatedDate = i;
                            else if (columnHeader.Equals("Cell", StringComparison.Ordinal))
                                indexCellId = i;
                            else if (columnHeader.Equals("L.ChMeas.MIMO.PRB.OL.Rank1 (None)", StringComparison.Ordinal))
                                indexRank1 = i;
                            else if (columnHeader.Equals("L.ChMeas.MIMO.PRB.OL.Rank2 (None)", StringComparison.Ordinal))
                                indexRank2 = i;
                            else if (columnHeader.Equals("L.ChMeas.MIMO.PRB.OL.Rank3 (None)", StringComparison.Ordinal))
                                indexRank3 = i;
                            else if (columnHeader.Equals("L.ChMeas.MIMO.PRB.OL.Rank4 (None)", StringComparison.Ordinal))
                                indexRank4 = i;
                            else if (columnHeader.Equals("NE Name", StringComparison.Ordinal))
                                indexNeName = i;
                            else if (columnHeader.Equals(fourGenDetect, StringComparison.Ordinal))
                                indexFourGenDetect = i;
                        }
                    }
                    if (indexCreatedDate < 1 || indexCellId < 1 || indexRank1 < 1 || indexRank2 < 1 || indexRank3 < 1 || indexRank4 < 1)
                        return result;
                    for (var i = 2; i <= numRows; i++)
                    {
                        DateTime createdDateUtc;
                        decimal rank1, rank2, rank3, rank4;

                        var cellEnodeBInfo = workSheet.Cells[i, indexCellId].Text;
                        if (string.IsNullOrEmpty(cellEnodeBInfo)
                            || !DateTime.TryParse(workSheet.Cells[i, indexCreatedDate].Value.ToString(), out createdDateUtc)
                            || !decimal.TryParse(workSheet.Cells[i, indexRank1].Value.ToString(), out rank1)
                            || !decimal.TryParse(workSheet.Cells[i, indexRank2].Value.ToString(), out rank2)
                            || !decimal.TryParse(workSheet.Cells[i, indexRank3].Value.ToString(), out rank3)
                            || !decimal.TryParse(workSheet.Cells[i, indexRank4].Value.ToString(), out rank4))
                            continue;


                        var cellName = GetCellInfo(cellEnodeBInfo, "Cell Name");
                        var cellId = GetCellInfo(cellEnodeBInfo, "Local Cell ID");
                        var enodeBId = GetCellInfo(cellEnodeBInfo, "eNodeB ID");
                        var neName = workSheet.Cells[i, indexNeName].Text;
                        var cellKpi = new TestPerformanceData()
                        {
                            TestId = testId,
                            InDateUtc = createdDateUtc,
                            DateWithoutTimeUtc = new DateTime(createdDateUtc.Year, createdDateUtc.Month, createdDateUtc.Day, 0, 0, 0),
                            CellName = cellName,
                            CellId = cellId,
                            Rank1 = rank1,
                            Rank2 = rank2,
                            Rank3 = rank3,
                            Rank4 = rank4,
                            EnodeBId = enodeBId,
                            NeName = neName

                        };
                        var readyForAdd = false;
                        //this kpi is for 4g cell
                        if (indexFourGenDetect > 0)
                        {
                            cellKpi.CellType = (int)CellTypeExtract.FourthGen;
                            decimal avgDb = 0;
                            if (decimal.TryParse(workSheet.Cells[i, indexFourGenDetect].Value.ToString(), out avgDb))
                            {
                                cellKpi.InterferenceAvg = avgDb;
                                readyForAdd = true;
                            }


                        }
                        if (readyForAdd)
                            result.Add(cellKpi);
                    }
                }
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task SendCellDataToStreamTest(List<TestPerformanceData> kpis)
        {
            if (kpis == null) return;
            if (kpis.Count == 0) return;
            var eventHubClient = EventHubClient.CreateFromConnectionString(
                ConfigurationManager.AppSettings["kpitest.ConnectionString"],
                ConfigurationManager.AppSettings["kpitest.Path"]);

            var batchList = new List<EventData>();
            long batchSize = 0;

            //foreach (var kpi in kpis)
            //{
            //    var jsonData = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(kpi));
            //    var eventData = new EventData(jsonData)
            //    {
            //        PartitionKey = "AMS-Test",
            //    };
            //    if ((batchSize + eventData.SerializedSizeInBytes) > 200000)
            //    {
            //        // Send current batch
            //        await eventHubClient.SendBatchAsync(batchList);

            //        // Initialize a new batch
            //        batchList = new List<EventData> { eventData };
            //        batchSize = eventData.SerializedSizeInBytes;
            //    }
            //    else
            //    {
            //        // Add the EventData to the current batch
            //        batchList.Add(eventData);
            //        batchSize += eventData.SerializedSizeInBytes;
            //    }
            //}
            //// The final batch is sent outside of the loop
            //await eventHubClient.SendBatchAsync(batchList);
            foreach (var kpi in kpis)
            {
                var jsonData = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(kpi));
                var eventData = new EventData(jsonData)
                {
                    PartitionKey = "AMS-Test",
                };
                await eventHubClient.SendAsync(eventData);
            }
            // The final batch is sent outside of the loop
           
        }


        public List<TestConfigurationReferenceOne> ExtractConfigurationFromListXml(List<string> xmlFiles, string testId)
        {
            var allConfiguration = new List<TestConfigurationReferenceOne>();
            foreach (var filePath in xmlFiles)
            {
                var splitFileName = filePath.Split('-');
                var fileName = splitFileName.LastOrDefault();
                if (string.IsNullOrEmpty(fileName))
                    continue;
                fileName = fileName.Replace(".xml", "");
                DateTime configDate;
                if (!DateTime.TryParseExact(fileName,
                                                   "ddMMyyyy",
                                                   CultureInfo.InvariantCulture,
                                                   DateTimeStyles.None,
                                                   out configDate))
                    continue;

                allConfiguration.AddRange(ExtractListConfigurationForSecondQuery(filePath, configDate));
            }
            return allConfiguration;
        }

        public void InsertBulkConfigurationForTesting(List<TestingConfiguration> configurations)
        {
            if (configurations == null || !configurations.Any()) return;
            string constr = ConfigurationManager.ConnectionStrings["AmsContext"].ConnectionString;
            var sb = new StringBuilder();
            sb.Append("INSERT INTO [TestingConfiguration] ( [Id], " +
                      " [TestId], " +
                      " [LocalCellId],[CellName],[TxRxMode],[CreatedDateUtc],[AdditionInfoForAtten]," +
                      " [AdditionInfoForPwr],[AllAttenDifferent],[AllAttenSame],[AllPwrDifferent],[AllPwrSame] " +
                      " ) VALUES ");
            for (var i = 1; i <= configurations.Count(); i++)
            {
                var configuration = configurations[i - 1];
                if (i % 1000 == 0)
                {
                    sb.Append(string.Format("('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}','{11}')",
                   Guid.NewGuid().ToString(),
                   configuration.TestId, configuration.LocalCellId, configuration.CellName,
                   configuration.TxRxMode,
                   configuration.CreatedDateUtc.ToString("yyyy-MM-dd'T'HH:mm:ss.FFF'Z'"),
                   configuration.AdditionInfoForAtten, configuration.AdditionInfoForPwr, configuration.AllAttenDifferent,
                   configuration.AllAttenSame, configuration.AllPwrDifferent, configuration.AllPwrSame));
                }
                else
                {
                    sb.Append(string.Format("('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}','{11}'),",
                   Guid.NewGuid().ToString(),
                   configuration.TestId, configuration.LocalCellId, configuration.CellName,
                   configuration.TxRxMode,
                   configuration.CreatedDateUtc.ToString("yyyy-MM-dd'T'HH:mm:ss.FFF'Z'"),
                   configuration.AdditionInfoForAtten, configuration.AdditionInfoForPwr, configuration.AllAttenDifferent,
                   configuration.AllAttenSame, configuration.AllPwrDifferent, configuration.AllPwrSame));
                }


                if (i % 1000 == 0)
                {
                    //process then reset
                    using (SqlConnection connection = new SqlConnection(constr))
                    {
                        connection.Open();
                        SqlCommand cmd = new SqlCommand(sb.ToString(), connection);
                        cmd.ExecuteNonQuery();

                    }
                    sb = new StringBuilder();
                    if (i < configurations.Count())
                        sb.Append("INSERT INTO [TestingConfiguration] ( [Id], " +
                    " [TestId], " +
                    " [LocalCellId],[CellName],[TxRxMode],[CreatedDateUtc],[AdditionInfoForAtten]," +
                    " [AdditionInfoForPwr],[AllAttenDifferent],[AllAttenSame],[AllPwrDifferent],[AllPwrSame] " +
                    " ) VALUES ");
                }

            }


            using (SqlConnection connection = new SqlConnection(constr))
            {
                connection.Open();
                SqlCommand cmd = new SqlCommand(sb.ToString().TrimEnd(','), connection);
                cmd.ExecuteNonQuery();
            }
        }

        public void ProcessTestingRequest(string testId)
        {
            //var testingRequest = GetTestingRequestById(testId);
            //if (testingRequest == null) return;
            //var allEventNeedToProcess = GetEventLogOfTestingRequest(testId);
            //var eventGroupByCellName = allEventNeedToProcess.GroupBy(p => p.CellName);
            ////process alarm record and history alarm record
            //foreach (var cellNameEvents in eventGroupByCellName)
            //{
            //    var eventGroupBySlogan = cellNameEvents.GroupBy(p => p.Slogan);
            //    foreach (var events in eventGroupBySlogan)
            //    {
            //        var sortevents = events.OrderBy(p => p.EventTime).ToList();

            //        foreach (var eve in sortevents)
            //        {
            //            ProcessAlarmForEvent(eve, testingRequest.StartTimeUtc, testingRequest.OriginalStartTimeUtc);
            //        }

            //    }

            //}
            ////update exactly datetime of eventlog via SP
            //UpdateExactlyTimeForEventLog(testId);

            var folderPath = "OutputTestRequest";
            var path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, folderPath);
            var file = testId + ".csv";
            path = Path.Combine(path, file);
            ExportTestingEventLogToCsv(testId, path);

        }

        public void SendListEvent(int second, List<EventRecord> eventRecords)
        {
            Trace.WriteLine("current time: " + DateTime.UtcNow + " Sending total " + eventRecords.Count + " at second: " + (second).ToString());

            try
            {
                TokenProvider credentials =
               TokenProvider.CreateSharedSecretTokenProvider
               ("amstesting", "FTM1gesuHRype5fYi3eEM0OMSVo42di2m+MveUE+e2g=");
                // Create a URI for the service bus.
                //Uri serviceBusUri = ServiceBusEnvironment.CreateServiceUri
                //    ("sb", "amsiotsystem", string.Empty);
              //  var manager = new NamespaceManager(serviceBusUri, credentials);
                var manager = new Microsoft.ServiceBus.NamespaceManager("sb://amsiotsystem.servicebus.windows.net/");

                var description = manager.CreateEventHubIfNotExists("testingamsnetworkalarm");
                var client = EventHubClient.Create(description.Path);
                foreach (var eventRecord in eventRecords)
                {
                    try
                    {
                        var jOb = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(eventRecord));
                        var evd = new EventData(jOb);

                        client.Send(evd);
                    }

                    catch (ArgumentNullException ex)
                    {
                        var u = 10;
                        throw;
                    }
                    catch (Exception ex)
                    {
                        var u = 10;
                        throw;
                    }
                }

            }
            catch (Exception e)
            {
                Console.WriteLine("SetupEHError" + e);


            }
           

        }

        #region utils



        private void ExportTestingEventLogToCsv(string testId, string filePathForSave)
        {
            string constr = ConfigurationManager.ConnectionStrings["AmsContext"].ConnectionString;

            SqlConnection spContentConn = new SqlConnection(constr);
            SqlCommand sqlcmd = new SqlCommand();
            StreamWriter CsvfileWriter = new StreamWriter(filePathForSave);
            sqlcmd.Connection = spContentConn;
            sqlcmd.CommandTimeout = 0;
            sqlcmd.CommandType = CommandType.Text;
            string sqlselectQuery = "SELECT EventTime,CellName,AverageRank,AverageInterference, Note FROM TestingLogEvent " +
                                    "Where TestId = '"+testId+"' Order by CellName,EventTime asc ";
                                   
            sqlcmd.CommandText = sqlselectQuery;
            spContentConn.Open();
            using (spContentConn)
            {
                using (var sdr = sqlcmd.ExecuteReader())
                using (CsvfileWriter)
                {
                    //This Block of code for getting the Table Headers
                    var tablecolumns = new DataTable();

                    for (int i = 0; i < sdr.FieldCount; i++)
                    {
                        tablecolumns.Columns.Add(sdr.GetName(i));
                    }
                    CsvfileWriter.WriteLine(string.Join(",", tablecolumns.Columns.Cast<DataColumn>().Select(csvfile => csvfile.ColumnName)));
                    while (sdr.Read())
                    {
                       
                        var d = (DateTime)sdr[0];
                        var dateStr = d.ToString("yyyy-MM-dd'T'HH:mm:ss.FFF'Z'");

                       
                        CsvfileWriter.WriteLine(dateStr + "," + sdr[1].ToString() + ","
                            + sdr[2].ToString() +  "," + sdr[3].ToString() + "," + sdr[4].ToString() +",");
                    }
                }
            }
            spContentConn.Close();

           
        }
        private void ExportTestingAlarmToCsv(string testId, string folderPath)
        {

        }
        private void ExportTestingHistoryAlarmToCsv(string testId, string folderPath)
        {

        }



        private void UpdateExactlyTimeForEventLog(string testId)
        {
            try
            {
               
                _dbContext.Database.ExecuteSqlCommand("EXEC FixExactTimeProcessTestingLogEvent @testId", testId);
               
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        private void UpdateTestingLogEvent(TestingLogEvent testingLogEvent)
        {
            try
            {
                _dbContext.Entry(testingLogEvent).State = EntityState.Modified;
                _dbContext.SaveChanges();

            }
            catch (Exception ex)
            {
                
            }
        }

        private List<TestingLogEvent> GetEventLogOfTestingRequest(string testId)
        {
            try
            {
                var res = _dbContext.Database.SqlQuery<TestingLogEvent>("PreProcessTestingLogEvent @testId",
                    new SqlParameter("@testId", testId));
                return res.ToList();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        private TestingSaRequest GetTestingRequestById(string testId)
        {
            if (string.IsNullOrEmpty(testId)) return null;
            var keyCache = string.Format(KeyForCacheTestingRecordById, testId);
            return _cacheManager.Get(keyCache, () =>
            {
                return _testingSaRequestDbSet.FirstOrDefault(p => p.Id == testId);
            });
        }

        private string GetCellInfo(string dataStr, string fieldName)
        {
            var data = dataStr.Split(',');
            var firstOrDefault = data.FirstOrDefault(x => x.Contains(fieldName));
            if (firstOrDefault != null)
            {
                var res = firstOrDefault.Split('=')[1];
                return res;
            }
            return "";
        }

        private TestAlarmRecord GetByCellNameAndSlogan(string cellName, string slogan,string testId)
        {
            if (string.IsNullOrEmpty(cellName) || string.IsNullOrEmpty(slogan)) return null;
            var keyCache = string.Format(KeyForCacheTestAlarmByCellNameAndSloganAndTestId, cellName, slogan, testId);
            //return _cacheManager.Get(keyCache, () =>
            //{
            //    return _testAlarmRecordDbSet.FirstOrDefault(p => p.CellName == cellName && p.Slogan == slogan &&p.TestId==testId);
            //});

            return _testAlarmRecordDbSet.FirstOrDefault(p => p.CellName == cellName && p.Slogan == slogan && p.TestId == testId);

        }

        private void InsertTestAlarmRecord(TestAlarmRecord testAlarmRecord)
        {
            var keyCache = string.Format(KeyForCacheTestAlarmByCellNameAndSloganAndTestId, testAlarmRecord.CellName, testAlarmRecord.Slogan,testAlarmRecord.TestId);
            _cacheManager.Remove(keyCache);
            _testAlarmRecordDbSet.Add(testAlarmRecord);
            _dbContext.SaveChanges();
        }
        private void InsertTestHistoryAlarmRecord(TestHistoryAlarmRecord testHistoryAlarmAlarmRecord)
        {
            //remove old 
            _dbContext.Database.ExecuteSqlCommand("DELETE [TestAlarmRecords] WHERE CellName = @p0 AND Slogan= @p1 AND TestId = @p2", testHistoryAlarmAlarmRecord.CellName, testHistoryAlarmAlarmRecord.Slogan,testHistoryAlarmAlarmRecord.TestId);

            //add new
            _testHistoryAlarmRecordDbSet.Add(testHistoryAlarmAlarmRecord);
            _dbContext.SaveChanges();

        }


        private TestingConfiguration GetConfigurationByCellNameAndDate(string cellName, DateTime date,string testId)
        {
            if (string.IsNullOrEmpty(cellName)|| string.IsNullOrEmpty(testId)) return null;
            var keyCache = string.Format(KeyForCacheTestingConfigurationByCellNameAndDateAndTestId, cellName, date.ToString("yy-mm-dd"),testId);
            return _cacheManager.Get(keyCache, () =>
            {
                return _testConfigurationDbSet.FirstOrDefault(p => p.CellName == cellName && p.CreatedDateUtc == date && p.TestId== testId);
            });
        }

        private List<TestConfigurationReferenceOne> ExtractListConfigurationForSecondQuery(string filePath, DateTime configDate)
        {
            var result = new List<TestConfigurationReferenceOne>();
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load(filePath);
            if (xmlDoc.DocumentElement != null)
            {
                #region get cell

                XmlNodeList nodeList = xmlDoc.DocumentElement.GetElementsByTagName("Cell");
                foreach (XmlNode node in nodeList)
                {
                    //example of <Cell>

                    //<attributes>
                    //	<LocalCellId>1</LocalCellId>
                    //	<CellName>202975_Rhodes_MV_L18A_1</CellName>
                    //	<CsgInd>0</CsgInd><!--False-->
                    //	<UlCyclicPrefix>0</UlCyclicPrefix><!--Normal-->
                    //	<DlCyclicPrefix>0</DlCyclicPrefix><!--Normal-->
                    //	<FreqBand>3</FreqBand>
                    //	<UlEarfcnCfgInd>0</UlEarfcnCfgInd><!--Not configure-->
                    //	<DlEarfcn>1550</DlEarfcn>
                    //	<UlBandWidth>5</UlBandWidth><!--20M-->
                    //	<DlBandWidth>5</DlBandWidth><!--20M-->
                    //	<CellId>11</CellId>
                    //	<PhyCellId>156</PhyCellId>
                    //	<AdditionalSpectrumEmission>1</AdditionalSpectrumEmission>
                    //	<CellActiveState>1</CellActiveState><!--Active-->
                    //	<CellAdminState>0</CellAdminState><!--Unblock-->
                    //	<FddTddInd>0</FddTddInd><!--FDD-->
                    //	<CellSpecificOffset>15</CellSpecificOffset><!--0dB-->
                    //	<QoffsetFreq>15</QoffsetFreq><!--0dB-->
                    //	<RootSequenceIdx>185</RootSequenceIdx>
                    //	<HighSpeedFlag>0</HighSpeedFlag><!--Low speed cell flag-->
                    //	<PreambleFmt>0</PreambleFmt>
                    //	<CellRadius>7000</CellRadius>
                    //	<CustomizedBandWidthCfgInd>0</CustomizedBandWidthCfgInd><!--Not configure-->
                    //	<EmergencyAreaIdCfgInd>0</EmergencyAreaIdCfgInd><!--Not configure-->
                    //	<UePowerMaxCfgInd>0</UePowerMaxCfgInd><!--Not configure-->
                    //	<MultiRruCellFlag>0</MultiRruCellFlag><!--False-->
                    //	<CPRICompression>1</CPRICompression><!--Normal Compression-->
                    //	<AirCellFlag>0</AirCellFlag><!--False-->
                    //	<CrsPortNum>2</CrsPortNum><!--2 ports-->
                    //	<TxRxMode>3</TxRxMode><!--2T4R-->
                    //	<UserLabel></UserLabel>
                    //	<WorkMode>0</WorkMode><!--Uplink and downlink-->
                    //	<EuCellStandbyMode>0</EuCellStandbyMode><!--Active-->
                    //	<CellSlaveBand>
                    //		<element>
                    //		</element>
                    //	</CellSlaveBand>
                    //	<CnOpSharingGroupId>255</CnOpSharingGroupId>
                    //	<IntraFreqRanSharingInd>1</IntraFreqRanSharingInd><!--True-->
                    //	<IntraFreqAnrInd>1</IntraFreqAnrInd><!--ALLOWED-->
                    //	<CellScaleInd>0</CellScaleInd><!--MACRO-->
                    //	<FreqPriorityForAnr>0</FreqPriorityForAnr>
                    //	<CellRadiusStartLocation>0</CellRadiusStartLocation>
                    //	<objId>0</objId>
                    //</attributes>

                    var attributes = node.FirstChild;
                    var configurationModel = new TestConfigurationReferenceOne();
                    try
                    {
                        var xmlElement = attributes["LocalCellId"];
                        if (xmlElement != null)
                            configurationModel.LocalCellId = xmlElement.InnerText;
                        var element = attributes["CellName"];
                        if (element != null)
                            configurationModel.CellName = element.InnerText;

                        configurationModel.TxRxMode = attributes["TxRxMode"]?.InnerText ?? "";
                        configurationModel.CreatedDateUtc = configDate;
                    }
                    catch (Exception ex)
                    {
                    }
                    if (string.IsNullOrEmpty(configurationModel.CellName)) continue;

                    if (result.FirstOrDefault(p => p.CellName == configurationModel.CellName) == null)
                    {
                        result.Add(configurationModel);
                    }
                }

                #endregion

                #region get eUCellSectorEqm
                //From CellName, search in eNodeB config , for getting SectorEqmId
                //      <eUCellSectorEqm>
                //	        <attributes>
                //		        <LocalCellId>22</LocalCellId>
                //		        <SectorEqmId>4</SectorEqmId>
                //		        <ReferenceSignalPwr>32767</ReferenceSignalPwr>
                //		        <BaseBandEqmId>255</BaseBandEqmId>
                //		        <ReferenceSignalPwrMargin>0</ReferenceSignalPwrMargin>
                //		        <SectorCpriCompression>255</SectorCpriCompression><!--Invalid-->
                //	        </attributes>
                //      </eUCellSectorEqm>

                var eUCellSectorEqms = new List<EuCellSectorEqm>();
                XmlNodeList noteEuCellSectorEqm = xmlDoc.DocumentElement.GetElementsByTagName("eUCellSectorEqm");
                foreach (XmlNode euCellSectorEq in noteEuCellSectorEqm)
                {
                    var attributes = euCellSectorEq.FirstChild;
                    var eUCellSectorEqm = new EuCellSectorEqm();
                    try
                    {
                        eUCellSectorEqm.LocalCellId = attributes["LocalCellId"]?.InnerText ?? "";
                        eUCellSectorEqm.SectorEqmId = attributes["SectorEqmId"]?.InnerText ?? "";
                    }
                    catch (Exception)
                    {
                    }
                    if (string.IsNullOrEmpty(eUCellSectorEqm.LocalCellId))
                        continue;
                    //add if not exist
                    if (eUCellSectorEqms.FirstOrDefault(p => p.LocalCellId == eUCellSectorEqm.LocalCellId) == null)
                    {
                        eUCellSectorEqms.Add(eUCellSectorEqm);
                    }
                }


                //fill Configuration with SectorId
                foreach (var configuration in result)
                {
                    var findSector = eUCellSectorEqms.FirstOrDefault(p => p.LocalCellId == configuration.LocalCellId);
                    if (findSector != null)
                        configuration.SectorEqmId = findSector.SectorEqmId;
                }
                //get only configuration has SectorEqmId
                result = result.Where(p => !string.IsNullOrEmpty(p.SectorEqmId)).ToList();

                #endregion

                #region get SECTOREQM
                // From SectorEqmId , search in <SECTOREQM>

                var sectoreqms = new List<Sectoreqm>();
                XmlNodeList noteSectoreqm = xmlDoc.DocumentElement.GetElementsByTagName("SECTOREQM");
                foreach (XmlNode sectoreqm in noteSectoreqm)
                {
                    var attributes = sectoreqm.FirstChild;
                    var sectoreqmModel = new Sectoreqm();
                    try
                    {
                        sectoreqmModel.SectorEqmId = attributes["SECTOREQMID"]?.InnerText ?? "";
                        //sectoreqmModel.Sectorid = attributes["SECTORID"]?.InnerText ?? "";
                        var xmlElement = attributes["SECTOREQMANTENNA"];
                        if (xmlElement != null)
                        {
                            var elements = xmlElement.ChildNodes;

                            foreach (XmlNode element in elements)
                            {
                                //value of element
                                //<element>
                                // <CN>0</CN>
                                // <SRN>4</SRN>
                                // <SN>1</SN>
                                // <ANTN>0</ANTN><!--R0A-->
                                // <ANTTYPE>1</ANTTYPE><!--RX-->
                                // <TXBKPMODE>0</TXBKPMODE><!--Master-->
                                //</element>
                                var item = new Element
                                {
                                    Cn = element["CN"]?.InnerText ?? "",
                                    Srn = element["SRN"]?.InnerText ?? "",
                                    Sn = element["SN"]?.InnerText ?? "",
                                    Antn = element["ANTN"]?.InnerText ?? ""
                                };
                                sectoreqmModel.Elements.Add(item);
                                sectoreqms.Add(sectoreqmModel);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                    }
                }

                //filter configuration with SectorEqmId
                foreach (var configuration in result)
                {
                    var sectoreqmModel = sectoreqms.FirstOrDefault(p => p.SectorEqmId == configuration.SectorEqmId);
                    if (sectoreqmModel != null)
                    {
                        configuration.RxBranchAndAntennaPortValues =
                            sectoreqmModel.Elements.Select(p => new OndemandTesting.Models.RxBranchAndAntennaPortValue()
                            {
                                Cn = p.Cn,
                                Antn = p.Antn,
                                Sn = p.Sn,
                                Srn = p.Srn
                            }).ToList();
                    }
                }

                #endregion

                #region get RXBRANCH

                var rxBranchs = new List<Rxbranch>();
                XmlNodeList rxBranchNodes = xmlDoc.DocumentElement.GetElementsByTagName("RXBRANCH");
                foreach (XmlNode rxBranchNode in rxBranchNodes)
                {
                    //<RXBRANCH>
                    // <attributes>
                    //  <CN>0</CN>
                    //  <SRN>4</SRN>
                    //  <SN>0</SN>
                    //  <RXNO>0</RXNO>
                    //  <RXSW>0</RXSW><!--ON-->
                    //  <ATTEN>22</ATTEN>
                    //  <RTWPINITADJ0>0</RTWPINITADJ0>
                    //  <RTWPINITADJ1>0</RTWPINITADJ1>
                    //  <RTWPINITADJ2>0</RTWPINITADJ2>
                    //  <RTWPINITADJ3>0</RTWPINITADJ3>
                    //  <RTWPINITADJ4>0</RTWPINITADJ4>
                    //  <RTWPINITADJ5>0</RTWPINITADJ5>
                    //  <RTWPINITADJ6>0</RTWPINITADJ6>
                    //  <RTWPINITADJ7>0</RTWPINITADJ7>
                    // </attributes>
                    //</RXBRANCH>

                    try
                    {
                        var attributes = rxBranchNode.FirstChild;
                        var rx = new Rxbranch
                        {
                            Cn = attributes["CN"]?.InnerText ?? "",
                            Srn = attributes["SRN"]?.InnerText ?? "",
                            Sn = attributes["SN"]?.InnerText ?? "",
                            RXNO = attributes["RXNO"]?.InnerText ?? "",
                            ATTEN = attributes["ATTEN"]?.InnerText ?? ""
                        };
                        rxBranchs.Add(rx);
                    }
                    catch (Exception ex)
                    {
                    }
                }

                //filter configuration with RXBRANCH
                foreach (var configuration in result)
                {
                    foreach (var element in configuration.RxBranchAndAntennaPortValues)
                    {
                        var rx =
                            rxBranchs.FirstOrDefault(
                                p =>
                                    p.Cn == element.Cn && p.Sn == element.Sn && p.Srn == element.Srn &&
                                    p.RXNO == element.Antn);
                        if (rx != null)
                        {
                            element.ATTEN = rx.ATTEN;
                        }
                    }
                }

                #endregion

                #region get ATTENNAPORT

                var AntennaPorts = new List<AntennaPort>();
                XmlNodeList AntennaPortNodes = xmlDoc.DocumentElement.GetElementsByTagName("ANTENNAPORT");
                foreach (XmlNode AntennaPortNode in AntennaPortNodes)
                {
                    //<ANTENNAPORT>
                    //	<attributes>
                    //		<CN>0</CN>
                    //		<SRN>4</SRN>
                    //		<SN>0</SN>
                    //		<PN>0</PN><!--R0A-->
                    //		<FEEDERLENGTH>0</FEEDERLENGTH>
                    //		<DLDELAY>100</DLDELAY>
                    //		<ULDELAY>100</ULDELAY>
                    //		<PWRSWITCH>1</PWRSWITCH><!--OFF-->
                    //		<THRESHOLDTYPE>5</THRESHOLDTYPE><!--TMA12DB_AISG-->
                    //		<UOTHD>30</UOTHD>
                    //		<UCTHD>40</UCTHD>
                    //		<OOTHD>450</OOTHD>
                    //		<OCTHD>400</OCTHD>
                    //		<ULTRADELAYSW>0</ULTRADELAYSW><!--OFF-->
                    //	</attributes>
                    //</ANTENNAPORT>

                    try
                    {
                        var attributes = AntennaPortNode.FirstChild;
                        var ap = new AntennaPort()
                        {
                            Cn = attributes["CN"]?.InnerText ?? "",
                            Srn = attributes["SRN"]?.InnerText ?? "",
                            Sn = attributes["SN"]?.InnerText ?? "",
                            Pn = attributes["PN"]?.InnerText ?? "",
                            Pwrswitch = attributes["PWRSWITCH"]?.InnerText ?? ""
                        };
                        AntennaPorts.Add(ap);
                    }
                    catch (Exception ex)
                    {
                    }
                }

                //filter configuration with RXBRANCH
                foreach (var configuration in result)
                {
                    foreach (var element in configuration.RxBranchAndAntennaPortValues)
                    {
                        var ap =
                            AntennaPorts.FirstOrDefault(
                                p =>
                                    p.Cn == element.Cn && p.Sn == element.Sn && p.Srn == element.Srn &&
                                    p.Pn == element.Antn);
                        if (ap != null)
                        {
                            element.POWERSWITCH = ap.Pwrswitch;
                            element.CombineValue = string.Format("CN={0},SRN={1},SN={2},PN={3}", ap.Cn, ap.Srn, ap.Sn, ap.Pn);
                        }
                    }
                }

                #endregion

                //clear element 
            }
            return result;
        }


        private TestingLogEvent ProcessAlarmForEvent(TestingLogEvent tevent, DateTime startTime, DateTime oristartTime)
        {
            var ti = tevent.EventTime.Subtract(startTime).TotalSeconds;
            var oriti = oristartTime.AddMinutes(15 * ti);
            var checkingAlarmRecord = GetByCellNameAndSlogan(tevent.CellName, tevent.Slogan, tevent.TestId);
            switch ((int)tevent.TestExecuteCode)
            {
                //cease alarm
                case 2:
                case 4:
                case 6:
                case 8:
                case 10:
                case 12:
                case 14:
                    {
                        CeaseAlarm(tevent, checkingAlarmRecord, oriti);
                        break;
                    }
                case 1:
                    {
                        #region add MIMO alarm

                        if (checkingAlarmRecord != null)
                        {
                            //update to DB that its exist before

                            tevent.Note = "Want to add MIMO. Do nothing cause exist MIMO before.";
                        }
                        else
                        {

                            AddAlarm(tevent, oriti);

                        }

                        #endregion
                        break;
                    }
                case 3:
                case 9:
                    {
                        #region add Daily Uplink Interference Step Change High/Low-ALD Power Modified Alarm

                        if (checkingAlarmRecord != null)
                        {
                            //update to DB that its exist before
                            tevent.Note =
                                "Want to add " + tevent.Slogan + ". Do nothing cause exist alarm before.";
                        }
                        else
                        {

                            var configurationPerThisRecord = GetConfigurationByCellNameAndDate(tevent.CellName,
                                tevent.DateWithoutTimeUtc, tevent.TestId);
                            if (configurationPerThisRecord == null)
                            {
                                tevent.Note =
                                    "Want to add " + tevent.Slogan + ". Do nothing cause configuration not found.";
                                break;
                            }
                            if (!configurationPerThisRecord.AllPwrDifferent)
                            {
                                tevent.Note =
                                    "Want to add " + tevent.Slogan + ". Do nothing cause AllPwrDifferent is False.";
                                break;
                            }

                            AddAlarm(tevent, oriti);
                        }

                        #endregion
                        break;
                    }
                case 5:
                case 11:
                    {
                        #region add Attenuation Values Modified - High/Low

                        if (checkingAlarmRecord != null)
                        {
                            //update to DB that its exist before
                            tevent.Note =
                                "Want to add " + tevent.Slogan + ". Do nothing cause exist alarm before.";
                        }
                        else
                        {
                            //check with configuration here
                            var configurationPerThisRecord = GetConfigurationByCellNameAndDate(tevent.CellName,
                                tevent.DateWithoutTimeUtc, tevent.TestId);
                            if (configurationPerThisRecord == null)
                            {
                                tevent.Note =
                                    "Want to add " + tevent.Slogan + ". Do nothing cause configuration not found.";
                                break;
                            }
                            if (!configurationPerThisRecord.AllAttenDifferent)
                            {
                                tevent.Note =
                                    "Want to add " + tevent.Slogan + ". Do nothing cause AllAttenDifferent is False.";
                                break;
                            }

                            AddAlarm(tevent, oriti);
                        }

                        #endregion

                        break;
                    }
                //add mimo
                case 7:
                case 13:
                    {
                        #region add Uplink Interference Step Change High/Low-Root Cause Unknown

                        if (checkingAlarmRecord != null)
                        {
                            //update to DB that its exist before
                            tevent.Note =
                                "Want to add "+tevent.Slogan+". Do nothing cause exist alarm before.";
                        }
                        else
                        {
                            //check with configuration here
                            var configurationPerThisRecord = GetConfigurationByCellNameAndDate(tevent.CellName,
                                tevent.DateWithoutTimeUtc, tevent.TestId);
                            if (configurationPerThisRecord == null)
                            {
                                tevent.Note =
                                    "Want to add " + tevent.Slogan + ". Do nothing cause configuration not found.";
                                break;
                            }
                            if (!configurationPerThisRecord.AllAttenSame || !configurationPerThisRecord.AllPwrSame)
                            {
                                tevent.Note =
                                    "Want to add " + tevent.Slogan + ". Do nothing cause AllAttenSame or AllPwrSame is False.";
                                break;
                            }

                            AddAlarm(tevent, oriti);
                        }

                        #endregion

                        break;
                    }
                

            }
            UpdateTestingLogEvent(tevent);
            return null;
        }

        private void AddAlarm(TestingLogEvent tevent, DateTime oriti)
        {
            var newTestAlarmRecords = new TestAlarmRecord()
            {
                TestId = tevent.TestId,
                CellName = tevent.CellName,
                Slogan = tevent.Slogan,
                MoClass = tevent.MoClass,
                AdditionInfo = tevent.AdditionInfo,
                Attribute = String.Format("CellName={0} ,Local CellId={1}", tevent.CellName, tevent.LocalCellId),
                CellType = tevent.CellType,
                ENodeBId = tevent.ENodeBId,
                MoInstance = tevent.MoInstance,
                LocalCellId = tevent.CellId,
                Severity = tevent.Severity,
                CreatedDateUtc = oriti
            };
            //write to test alarm record
            InsertTestAlarmRecord(newTestAlarmRecords);
            //clear cache 
            var keyCache = string.Format(KeyForCacheTestAlarmByCellNameAndSloganAndTestId, newTestAlarmRecords.CellName,
                newTestAlarmRecords.Slogan, newTestAlarmRecords.TestId);
            _cacheManager.Set(keyCache, newTestAlarmRecords, 15);
            tevent.Note = "add "+tevent.Slogan+" Success";
        }

        private void CeaseAlarm(TestingLogEvent tevent, TestAlarmRecord checkingAlarmRecord, DateTime oriti)
        {
            if (checkingAlarmRecord == null)
            {
                //update to DB that its exist before
                tevent.Note =
                    "Want to cease "+ tevent .Slogan+ ". Do nothing cause not exist alarm before.";
            }
            else
            {
                var newTestHistoryAlarmRecords = new TestHistoryAlarmRecord()
                {
                    TestId = checkingAlarmRecord.TestId,
                    CellName = checkingAlarmRecord.CellName,
                    Slogan = checkingAlarmRecord.Slogan,
                    MoClass = checkingAlarmRecord.MoClass,
                    MoInstance = checkingAlarmRecord.MoInstance,
                    AdditionInfo = checkingAlarmRecord.AdditionInfo,
                    Attribute = checkingAlarmRecord.Attribute,
                    CellType = checkingAlarmRecord.CellType,
                    LocalCellId = checkingAlarmRecord.LocalCellId,
                    CreatedDateUtc = checkingAlarmRecord.CreatedDateUtc,
                    CeaseDateTimeUtc = oriti,
                    Severity = checkingAlarmRecord.Severity
                };
                InsertTestHistoryAlarmRecord(newTestHistoryAlarmRecords);
                var keyCache = string.Format(KeyForCacheTestingConfigurationByCellNameAndDateAndTestId,
                    newTestHistoryAlarmRecords.CellName, newTestHistoryAlarmRecords.Slogan, newTestHistoryAlarmRecords.TestId);
                //_cacheManager.Set(keyCache, null, 15);
                _cacheManager.Remove(keyCache);

                tevent.Note = "Want to cease "+ tevent.Slogan + " => Cease success.";
            }
        }

        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Core.Domain.Business;
using Core.Domain.Business.StreamAnalyticEntity;

namespace StreamAnalyticService
{
    public interface IAlarmRecordReferenceService
    {
        /// <summary>
        /// export SQL to CSV and upload to blob
        /// </summary>
        void ExportToCsvAndUploadToBlob(List<AlarmRecord> alarmRecords);




    }
}

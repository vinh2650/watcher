﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common.Helpers;
using Core;
using Core.Domain.Business;
using Core.Domain.Business.StreamAnalyticEntity;
using Service.Interface;

namespace StreamAnalyticService
{
    public class TaskForProcessTestingDataService:ITaskForProcessTestingDataService
    {
        private readonly ITestingSaRequestService _testingSaRequestService;
        private readonly IEmailService _emailService;
        private string fromEmail = ConfigurationManager.AppSettings["FromEmail"];
        private string fromName = ConfigurationManager.AppSettings["FromName"];
        public TaskForProcessTestingDataService(ITestingSaRequestService testingSaRequestService, IEmailService emailService)
        {
            _testingSaRequestService = testingSaRequestService;
            _emailService = emailService;
        }


        public void ProcessDataPer5Minute()
        {
            var listTestRequests = _testingSaRequestService.GetAllTestRequest();
            //check test request has pending
            var listPendingRequest = listTestRequests.Where(p => p.TestingStatus == TestingStatus.Pending);
            //check test request is valid for process
            foreach (var tRequest in listPendingRequest)
            {
                var startTime = tRequest.StartTimeUtc;
                var TimeWillEnd = startTime.AddSeconds(tRequest.TotalSecondHasBeenAdd + tRequest.TotalSecondHasBeenAdd);
                if (TimeWillEnd < DateTime.UtcNow)
                {

                    tRequest.TestingStatus=TestingStatus.Processing;
                    _testingSaRequestService.UpdateTestRequest(tRequest);
                    //process
                    var logEvents =
                        _testingSaRequestService.GetEventByTestId(tRequest.Id)
                            .OrderBy(p => p.CellName)
                            .ThenBy(n => n.CreatedDateUtc);
                    foreach (var logEvent in logEvents)
                    {
                        //code 1
                        if (logEvent.TestExecuteCode == TestExecuteCode.AddMimo)
                        {
                            //check configuration first
                            var configurationCheck = _testingSaRequestService.GetTestConfigurationByName(tRequest.Id,
                                logEvent.CellName);
                            if (configurationCheck == null)
                            {
                                //update event
                                logEvent.Note = "No configuration for this cell=> Do nothing";
                                _testingSaRequestService.UpdateLogEventTesting(logEvent);
                                continue;
                                
                            }
                            if (configurationCheck.TxRxMode!="2")
                            {
                                //update event
                                logEvent.Note = "TXRX mode is "+ configurationCheck.TxRxMode + " . => Do nothing";
                                _testingSaRequestService.UpdateLogEventTesting(logEvent);
                                continue;

                            }


                            var checkAlarm = _testingSaRequestService.GetSampleAlarmOfTesting(tRequest.Id, logEvent.CellName,
                                "MIMO degradation");
                            if (checkAlarm == null)
                            {
                                _testingSaRequestService.CreateSampleOutputsForTesting(new List<TestAlarmRecord>()
                                {
                                    new TestAlarmRecord()
                                    {
                                        TestId = tRequest.Id,
                                        CellName = logEvent.CellName,
                                        CreatedDateUtc = logEvent.CreatedDateUtc,
                                        Slogan = "MIMO degradation",
                                        LocalCellId = logEvent.LocalCellId
                                    }
                                });
                                //update event
                                logEvent.Note = "Want to add alarm => Don't exist alarm before => Just add new alarm";
                                _testingSaRequestService.UpdateLogEventTesting(logEvent);
                            }
                            else
                            {
                                //update event 
                                logEvent.Note = "Want to add alarm =>  Exist alarm before => Do nothing";
                                _testingSaRequestService.UpdateLogEventTesting(logEvent);
                            }
                        }
                        //code 2
                        else if (logEvent.TestExecuteCode == TestExecuteCode.CeaseMimo)
                        {
                            var checkAlarm = _testingSaRequestService.GetSampleAlarmOfTesting(tRequest.Id, logEvent.CellName,
                                "MIMO degradation");
                            if (checkAlarm != null)
                            {
                                _testingSaRequestService.RemoveSampleOutput(tRequest.Id, logEvent.CellName);

                                _testingSaRequestService.CreateHistoryOutputsForTesting(new TestHistoryAlarmRecord()
                                {
                                    TestId = tRequest.Id,
                                    LocalCellId = checkAlarm.LocalCellId,
                                    CellName = logEvent.CellName,
                                    CreatedDateUtc = checkAlarm.CreatedDateUtc,
                                    Slogan = "MIMO degradation",
                                    CeaseDateTimeUtc = logEvent.CreatedDateUtc
                                });
                                //update event
                                logEvent.Note = "Want to CEASE alarm => Exist alarm before => Cease alarm";
                                _testingSaRequestService.UpdateLogEventTesting(logEvent);
                            }
                            else
                            {
                                //update event 
                                logEvent.Note = "Want to CEASE alarm => Dont exist alarm before => Do nothing";
                                _testingSaRequestService.UpdateLogEventTesting(logEvent);
                            }
                        }
                        else
                        {
                         //do nothing 
                        }
                    }
                    //save event log as CSV
                    var folderPath = "OutputTestRequest";
                    _testingSaRequestService.ExportTestEventToCsv(tRequest.Id,folderPath);

                    //save alarm active as CSV
                    _testingSaRequestService.ExportTestActiveAlarmToCsv(tRequest.Id, folderPath);

                    // save history alarm active as CSV
                    _testingSaRequestService.ExportTestHistoryAlarmToCsv(tRequest.Id, folderPath);

                    // send all in email

                
                    //var domain = ConfigurationManager.AppSettings["BaseUrl"];
                    var listFilePath = new List<AttachmentForTesting>();
                    listFilePath.Add(new AttachmentForTesting {
                        Path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, folderPath,
                        "eventlogs-" + tRequest.Id + ".csv"),
                    Name = "eventlogs-" + tRequest.Id + ".csv"
                    });

                    listFilePath.Add(new AttachmentForTesting
                    {
                        Path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, folderPath,
                        "activealarms-" + tRequest.Id + ".csv"),
                        Name = "activealarms-" + tRequest.Id + ".csv"
                    });

                    listFilePath.Add(new AttachmentForTesting
                    {
                        Path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, folderPath,
                        "historyalarms-" + tRequest.Id + ".csv"),
                        Name = "historyalarms-" + tRequest.Id + ".csv"
                    });


                    AsyncHelper.RunSync(() => _emailService.SendEmailForTestingRequestAsync(fromEmail,
                        fromName,
                        new List<string>() {tRequest.EmailAddress},
                        null,
                        null,
                        "Test SA result",
                        "Here is your result for request with ID: " + tRequest.Id, listFilePath

                        ));
                    

                    
                    //TODO maybe send input data too

                    tRequest.TestingStatus = TestingStatus.Success;
                    _testingSaRequestService.UpdateTestRequest(tRequest);
                }
                else
                {
                    //do nothing
                }

            }

            //delete list complete
            var listCompleteRequest = listTestRequests.Where(p => p.TestingStatus == TestingStatus.Success);
        }

        public void ProcessDataForTestingRequest(string testId)
        {
            Trace.TraceError("Process for testing "+ testId);
            var tRequest = _testingSaRequestService.GetTestRequest(testId);
            if (tRequest == null) return;
            if (tRequest.TestingStatus != TestingStatus.Pending) return;

            tRequest.TestingStatus = TestingStatus.Processing;
            _testingSaRequestService.UpdateTestRequest(tRequest);
            //process
            var logEvents =
                _testingSaRequestService.GetEventByTestId(tRequest.Id)
                    .OrderBy(p => p.CellName)
                    .ThenBy(n => n.CreatedDateUtc);
            foreach (var logEvent in logEvents)
            {
                //code 1
                if (logEvent.TestExecuteCode == TestExecuteCode.AddMimo)
                {
                    //check configuration first
                    var configurationCheck = _testingSaRequestService.GetTestConfigurationByName(tRequest.Id,
                        logEvent.CellName);
                    if (configurationCheck == null)
                    {
                        //update event
                        logEvent.Note = "No configuration for this cell=> Do nothing";
                        _testingSaRequestService.UpdateLogEventTesting(logEvent);
                        continue;

                    }
                    if (configurationCheck.TxRxMode != "2")
                    {
                        //update event
                        logEvent.Note = "TXRX mode is " + configurationCheck.TxRxMode + " . => Do nothing";
                        _testingSaRequestService.UpdateLogEventTesting(logEvent);
                        continue;

                    }


                    var checkAlarm = _testingSaRequestService.GetSampleAlarmOfTesting(tRequest.Id, logEvent.CellName,
                        "MIMO degradation");
                    if (checkAlarm == null)
                    {
                        _testingSaRequestService.CreateSampleOutputsForTesting(new List<TestAlarmRecord>()
                                {
                                    new TestAlarmRecord()
                                    {
                                        TestId = tRequest.Id,
                                        CellName = logEvent.CellName,
                                        CreatedDateUtc = logEvent.CreatedDateUtc,
                                        Slogan = "MIMO degradation",
                                        LocalCellId = logEvent.LocalCellId
                                    }
                                });
                        //update event
                        logEvent.Note = "Want to add alarm => Don't exist alarm before => Just add new alarm";
                        _testingSaRequestService.UpdateLogEventTesting(logEvent);
                    }
                    else
                    {
                        //update event 
                        logEvent.Note = "Want to add alarm =>  Exist alarm before => Do nothing";
                        _testingSaRequestService.UpdateLogEventTesting(logEvent);
                    }
                }
                //code 2
                else if (logEvent.TestExecuteCode == TestExecuteCode.CeaseMimo)
                {
                    var checkAlarm = _testingSaRequestService.GetSampleAlarmOfTesting(tRequest.Id, logEvent.CellName,
                        "MIMO degradation");
                    if (checkAlarm != null)
                    {
                        _testingSaRequestService.RemoveSampleOutput(tRequest.Id, logEvent.CellName);

                        _testingSaRequestService.CreateHistoryOutputsForTesting(new TestHistoryAlarmRecord()
                        {
                            TestId = tRequest.Id,
                            LocalCellId = checkAlarm.LocalCellId,
                            CellName = logEvent.CellName,
                            CreatedDateUtc = checkAlarm.CreatedDateUtc,
                            Slogan = "MIMO degradation",
                            CeaseDateTimeUtc = logEvent.CreatedDateUtc
                        });
                        //update event
                        logEvent.Note = "Want to CEASE alarm => Exist alarm before => Cease alarm";
                        _testingSaRequestService.UpdateLogEventTesting(logEvent);
                    }
                    else
                    {
                        //update event 
                        logEvent.Note = "Want to CEASE alarm => Dont exist alarm before => Do nothing";
                        _testingSaRequestService.UpdateLogEventTesting(logEvent);
                    }
                }
                else
                {
                    //do nothing 
                }
            }
            //save event log as CSV
            var folderPath = "OutputTestRequest";
            _testingSaRequestService.ExportTestEventToCsv(tRequest.Id, folderPath);

            //save alarm active as CSV
            _testingSaRequestService.ExportTestActiveAlarmToCsv(tRequest.Id, folderPath);

            // save history alarm active as CSV
            _testingSaRequestService.ExportTestHistoryAlarmToCsv(tRequest.Id, folderPath);

            // send all in email


            //var domain = ConfigurationManager.AppSettings["BaseUrl"];
            var listFilePath = new List<AttachmentForTesting>();
            listFilePath.Add(new AttachmentForTesting
            {
                Path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, folderPath,
                "eventlogs-" + tRequest.Id + ".csv"),
                Name = "eventlogs-" + tRequest.Id + ".csv"
            });

            listFilePath.Add(new AttachmentForTesting
            {
                Path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, folderPath,
                "activealarms-" + tRequest.Id + ".csv"),
                Name = "activealarms-" + tRequest.Id + ".csv"
            });

            listFilePath.Add(new AttachmentForTesting
            {
                Path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, folderPath,
                "historyalarms-" + tRequest.Id + ".csv"),
                Name = "historyalarms-" + tRequest.Id + ".csv"
            });


            AsyncHelper.RunSync(() => _emailService.SendEmailForTestingRequestAsync(fromEmail,
                fromName,
                new List<string>() { tRequest.EmailAddress },
                null,
                "khanh.vu@newoceaninfosys.com",
                "Test SA result",
                "Here is your result for request with ID: " + tRequest.Id, listFilePath

                ));



            //TODO maybe send input data too

            tRequest.TestingStatus = TestingStatus.Success;
            _testingSaRequestService.UpdateTestRequest(tRequest);

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Core.Domain.Business.StreamAnalyticEntity;
using OfficeOpenXml;
using StreamAnalyticService.OndemandTesting.Models;

namespace StreamAnalyticService.OndemandTesting
{
    /// <summary>
    /// Extract data service for on-demand testing
    /// </summary>
    public interface ITestingExtractDataForSaService
    {
        List<TestPerformanceData> ExtractKpiForTesting(Stream stream, string testId);

        Task SendCellDataToStreamTest(List<TestPerformanceData> kpi);

       // List<TestingLogEvent> GetEventLogOfTestingRequest(string testId);

        List<TestConfigurationReferenceOne> ExtractConfigurationFromListXml(List<string> xmlFiles, string testId);


        void InsertBulkConfigurationForTesting(List<TestingConfiguration> configurations);

        void ProcessTestingRequest(string testId);

        void SendListEvent(int second, List<EventRecord> eventRecords);
    }


    #region test
    public class EventRecord
    {
        public string Severity { get; set; }

        public string Attribute { get; set; }

        public string MoInstance { get; set; }

        public string AdditionInfo { get; set; }

        public DateTime OccurredOn { get; set; }

        public int CellType { get; set; }

        public string LocalCellId { get; set; }

        public string CellName { get; set; }

        public string MoClass { get; set; }

        public string ENodeBId { get; set; }

        public string State { get; set; }

        public string TestId { get; set; }


        public double TotalSecondAdd { get; set; }

        public DateTime DateWithoutTimeUtc { get; set; }
    }
    #endregion


}

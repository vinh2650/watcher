﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StreamAnalyticService
{
    /// <summary>
    /// Service for extract data from cell (xlsx file)
    /// </summary>
    public interface ICellDataProcessService
    {
        /// <summary>
        /// extract cell data from excel file
        /// </summary>
        /// <param name="folderPath"></param>
        /// <param name="dateTime">The suffix of file name. "-ddMMyyyy-HHmm.xlsx" will be used </param>
        List<CellDataExtract> ExtractData(string folderPath,string dateTime = null);

        /// <summary>
        /// extract cell data from excel file
        /// </summary>
        /// <param name="stream"></param>
        /// <returns></returns>
        List<CellDataExtract> ExtractData(Stream stream);
        /// <summary>
        /// extract cell data from excel file
        /// </summary>
        /// <param name="stream"></param>
        /// <returns></returns>
        List<CellDataExtract> ExtractDataForTesting(Stream stream,string testId);
        /// <summary>
        /// Send data to stream
        /// </summary>
        /// <returns></returns>
        Task SendCellDataToStream(List<CellDataExtract> data);


        /// <summary>
        /// Send data to stream
        /// </summary>
        /// <returns></returns>
        Task SendCellDataToStreamTest(List<CellDataExtract> data);

        /// <summary>
        /// Send data to stream
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        Task SendCellDataToStream(CellDataExtract data);

    }
}

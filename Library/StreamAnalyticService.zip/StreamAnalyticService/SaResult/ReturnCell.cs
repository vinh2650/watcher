﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StreamAnalyticService.SaResult
{
    public class ReturnCell
    {
        public string TestId { get; set; }
        /// <summary>
        /// Cell Id, 
        /// </summary>
        public string CellId { get; set; }

        /// <summary>
        /// Cell Type, 
        /// </summary>
        public int CellType { get; set; }


        public string EnodeBId { get; set; }

        /// <summary>
        /// Cell Name, 
        /// </summary>
        public string CellName { get; set; }

        public string AvgRank { get; set; }


        public string Slogan { get; set; }

        public int EventCount { get; set; }

        public string CreatedDateUtc { get; set; }

        public string EventTime { get; set; }
    }


    public class KpiLogReturn
    {

        /// <summary>
        /// WindowEnds\
        /// </summary>
        public string WindowEnd { get; set; }

        /// <summary>
        /// Cell Name, 
        /// </summary>
        public string CellName { get; set; }

        public string CellId { get; set; }

        public long? InterferenceAvg { get; set; }

        /// <summary>
        /// Rtwp, 
        /// </summary>
        public long? Rtwp { get; set; }

        /// <summary>
        /// Cell Type, 
        /// </summary>
        public int CellType { get; set; }

    }
}
